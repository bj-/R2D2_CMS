#!/bin/bash

# Shturman_Functions_BEGIN

#ShturmanIniFilePath="/opt/shturman/bin/Shturman.ini"
ShturmanLogPath="/opt/shturman/bin/Log"
UploadFromDir="/opt/shturman/upload"

ShturmanIniFile="/opt/shturman/bin/Shturman.ini"
Shturman3IniFile="/opt/shturman/bin/Shturman3.ini"

ShturmanDiosIniFile="/opt/shturman/bin/Dios.ini"

function ExtractServiceVersionFromLogFile
{
	local serviceName=${1}

	if [ -f "/opt/shturman/bin/Log/Shturman${serviceName}-$(date +"%y.%m.%d").log" ]
	then
		#local ret="$(cat /opt/shturman/bin/Log/Shturman${serviceName}-$(date +"%y.%m.%d").log | grep -w "00106" | tail -n 1 | sed 's/^.*версия \[//')"
		local stat="$(cat /opt/shturman/bin/Log/Shturman${serviceName}-$(date +"%y.%m.%d").log | grep -w -E "00106|00116" | sed 's/^.*версия \[//')"

		local startCnt=$(echo -n "$stat" | grep -c '^')

		local ver="$(echo "$stat" | tail -n 1)"

		ret="${ver%]*}:${startCnt}"
		#ret="${ret%]*};${startCnt}"
		#ocal ret="$(cat /opt/shturman/bin/Log/Shturman${serviceName}-$(date +"%y.%m.%d").log | grep "00106" | tail -n 1 | sed 's/^.*версия \[//' | sed 's/\]//')"
		echo $ret
	fi
	
}

function BlockConfigurationReport
{
	if [ -f "${Shturman3IniFile}" ] 
	then
		local Core="Multi Core"
	        local BlockSerialNo="$(ini_get_parameter_value "${Shturman3IniFile}" "Hub" "Alias")"
        	#local BlockSerialNo="$(cat $FileName | sed -nr "/^\[Hub\]/ { :l /^Alias[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;})"
        	local Orientation="$(ini_get_parameter_value "${Shturman3IniFile}" "Dios" "Orientation")"
        	local BaseRoute="$(ini_get_parameter_value "${Shturman3IniFile}" "Dios" "BaseRoute")"
        	local MaxRoute="$(ini_get_parameter_value "${Shturman3IniFile}" "Dios" "MaxRoute")"
        	local CurrentRoute="$(ini_get_parameter_value "${ShturmanDiosIniFile}" "Route" "CurrentRoute")"
		if [[ $CurrentRoute = *"ERROR"* ]]
		then
			CurrentRoute="N/A"
		fi
        	#local Orientation="$(cat $FileName | sed -nr "/^\[Dios\]/ { :l /^Orientation[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;})"
        	local ServerPool="$(ini_get_parameter_value "${Shturman3IniFile}" "HubBridge.Pool" "Gate01")"
        	local ServerPing="$(ini_get_parameter_value "${Shturman3IniFile}" "Netmon" "ServerName")"
        	#local ServerPool="$(cat $FileName | sed -nr "/^\[HubBridge.Pool\]/ { :l /^Gate01[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;})"
        	#local
	elif [ -f "${ShturmanIniFile}" ]
	then
		local Core="Single Core"
		local BlockSerialNo="$(ini_get_parameter_value "${ShturmanIniFile}" "Hub" "BlockSerialNo")"
                local Orientation="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "Orientation")"
		local BaseRoute="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "BaseRoute")"
        	local MaxRoute="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "MaxRoute")"
     		local CurrentRoute="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "CurrentRoute")"
                local ServerPool="$(ini_get_parameter_value "${ShturmanIniFile}" "Hub" "Host")"
                local ServerPing="$(ini_get_parameter_value "${ShturmanIniFile}" "NetworkMonitor" "ServerName")"
	else
		local Core="N/A"
		local BlockSerialNo="N/A"
                local Orientation="N/A"
                local BaseRoute="N/A"
                local MaxRoute="N/A"
                local CurrentRoute="N/A"
                local ServerPool="N/A"
                local ServerPing="N/A"
	fi
	local ShturmanPacketsList="$(dpkg-query --list | grep "turman" | awk '{print $2 " ("$3"); " }' | tr -d '\n')"
	local ShturmanPacketsListCompact="$(dpkg-query --list | grep "turman" | awk '{print $2 "|"$3";"}' | tr -d '\n')"
	local ShturmanConfigPacket="$(dpkg-query --list | grep "turman-config" | awk '{print $2 " ("$3"); " }' | tr -d '\n')"
	local ShturmanConfigPacketCompact="$(dpkg-query --list | grep "turman-config" | awk '{print $2 ";" $3}' | tr -d '\n')"
	local ServicesStarting="$(systemctl --all | grep "Shturman" | grep -E "start" | awk '{print $1}' | sed 's/.service/ /' | sed 's/shturman//' | tr -d '\n')"
	local ServicesRunning="$(systemctl --all | grep "Shturman" | grep -E "running|exited" | awk '{print $1}' | sed 's/.service/ /' | sed 's/shturman//' | tr -d '\n')"
	local ServicesStopped="$(systemctl --all | grep "Shturman" | grep -E "dead" | awk '{print $1}' | sed 's/.service/ /' | sed 's/shturman//' | tr -d '\n')"
	if [ -f "/opt/shturman/bin/Log/ShturmanDios-$(date +"%y.%m.%d").log" ]
	then
		local FirmwareEINK="$(cat /opt/shturman/bin/Log/ShturmanDios-$(date +"%y.%m.%d").log | grep -w "06128" | tail -n 1)"
	else
		local FirmwareEINK="N/A"
	fi
	#local FirmwareEINK="[14:35:28.152] MSG:  06128  Получена от EInk версия Firmware: [16777226]"
	#local FirmwareEINKDate=$(grep -a "[0-9]\{2\}:[0-9]\{2\}:[0-9]\{2\}" $FirmwareEINK)
	#local FirmwareEINKDate=$(echo $FirmwareEINK | grep -a "[0-9]")
	local FirmwareEINKTime="$(echo ${FirmwareEINK%.*} | sed 's/\[//')"
	#local FirmwareEINKDate="$(echo ${FirmwareEINK%.*} | awk '{print $1}' | sed 's/\[//' | sed 's/\]//')"
	
	local FirmwareEINKVer="${FirmwareEINK%]*}"
	local FirmwareEINKVer="$(echo ${FirmwareEINKVer} | sed 's/.*: \[//' | sed 's/\]//')"
	local FirmwareEINKVerHEX="$(printf '%x\n' ${FirmwareEINKVer})"
	#FirmwareEINKDate="ddd"
	#local FirmwareEINKDate="$(echo ${FirmwareEINK} | sed 's/^.*([0-9]).*$/\1/')"
	#echo $FirmwareEINK
	local IPAddreesses="$(echo "$(hostname -I)" | sed 's/ $//')"

	#"[21:02:39.579] MSG:  00106  Служба [ShturmanCron] версия [3.0.6.3]"
	
	local SoftwareVerBluegigaCompact=$(ExtractServiceVersionFromLogFile Bluegiga)
	local SoftwareVerBluegiga="${NC}Bluegiga:${PURPLE} ${SoftwareVerBluegigaCompact};"
	local SoftwareVerCronCompact=$(ExtractServiceVersionFromLogFile Cron)
	local SoftwareVerCron="${NC}Cron:${PURPLE} ${SoftwareVerCronCompact};"
	local SoftwareVerDiosCompact=$(ExtractServiceVersionFromLogFile Dios)
	local SoftwareVerDios="${NC}Dios:${PURPLE} ${SoftwareVerDiosCompact};"
	local SoftwareVerHubCompact=$(ExtractServiceVersionFromLogFile Hub)
	local SoftwareVerHub="${NC}Hub:${PURPLE} ${SoftwareVerHubCompact};"
	local SoftwareVerLogicCompact=$(ExtractServiceVersionFromLogFile Logic)
	local SoftwareVerLogic="${NC}Logic:${PURPLE} ${SoftwareVerLogicCompact};"
	local SoftwareVerMathCompact=$(ExtractServiceVersionFromLogFile Math)
	local SoftwareVerMath="${NC}Math:${PURPLE} ${SoftwareVerMathCompact};"
	local SoftwareVerModemsCompact=$(ExtractServiceVersionFromLogFile Modems)
	local SoftwareVerModems="${NC}Modems:${PURPLE} ${SoftwareVerModemsCompact};"
	local SoftwareVerNetmonCompact=$(ExtractServiceVersionFromLogFile Netmon)
	local SoftwareVerNetmon="${NC}Netmon:${PURPLE} ${SoftwareVerNetmonCompact};"
	local SoftwareVerPowerCompact=$(ExtractServiceVersionFromLogFile Power)
	local SoftwareVerPower="${NC}Power:${PURPLE} ${SoftwareVerPowerCompact};"
	local SoftwareVerSoundCompact=$(ExtractServiceVersionFromLogFile Sound)
	local SoftwareVerSound="${NC}Sound:${PURPLE} ${SoftwareVerSoundCompact};"
	local SoftwareVerUdevCompact=$(ExtractServiceVersionFromLogFile Udev)
	local SoftwareVerUdev="${NC}Udev:${PURPLE} ${SoftwareVerUdevCompact};"

	local MAK_usb="$(ifconfig | grep usb | awk '{print $NF}')"
	local MAK_wlan="$(ifconfig | grep wlan | awk '{print $NF}')"
	local UUID_nanda="$(blkid | grep 'nanda' | grep -oP 'UUID="\K[^"]+')"
	local UUID_sda="$(blkid | grep 'sda' | grep -oP 'UUID="\K[^"]+')"
	local UID_Hardware="$(echo "${MAK_usb}${UUID_nanda}${UUID_sda}" | sha256sum | awk '{print $1}')"


        WriteLog "Configuration Report" "INFO" ""
	WriteLog "Version Type:       [${PURPLE}${Core}${NC}]" "INFO" ""
        WriteLog "Hostname:           [${PURPLE}$(hostname)${NC}]" "INFO" ""
        WriteLog "BlockSerialNo:      [${PURPLE}${BlockSerialNo}${NC}]" "INFO" ""
        #WriteLog "BlockSerialNo:      [${PURPLE}$(sudo cat /opt/shturman/bin/Shturman.ini | grep "^BlockSerialNo=" )${NC}]" "INFO" ""
        WriteLog "Block Orientation:  [${PURPLE}${Orientation}${NC}] (true = cable BOTTOM side / false = cable UP side) " "INFO" ""
        WriteLog "Block Routes:       [ ${PURPLE}${BaseRoute}${NC} / ${PURPLE}${CurrentRoute}${NC} / ${PURPLE}${MaxRoute}${NC} ] min / current / max " "INFO" ""
        WriteLog "Server Pool Addr:   [${PURPLE}${ServerPool}${NC}], Check network by [${PURPLE}${ServerPing}${NC}] " "INFO" ""
        #WriteLog "Block Orientation:  [${PURPLE}$(sudo cat /opt/shturman/bin/Shturman.ini | grep "^Orientation")${NC}] (true = cable BOTTOM side / false = cable UP side) " "INFO" ""
        WriteLog "Packets installed:  [${PURPLE}${ShturmanPacketsList}${NC}]" "INFO" ""
	WriteLog "Services run/stop:  [${GREEN}${ServicesRunning}${NC} / ${YELLOW}${ServicesStarting} ${RED}${ServicesStopped}${NC}]" "INFO" ""
        WriteLog "Configuration Pack: [${PURPLE}${ShturmanConfigPacket}${NC}]" "INFO" ""
        #WriteLog "Packets installed:  [${PURPLE}$(dpkg-query --list | grep "turman" )${NC}]" "INFO" ""
        #WriteLog "Packet Version:     [${PURPLE}--${NC}]" "INFO" ""
        WriteLog "IP Addresses        [${PURPLE}${IPAddreesses}${NC}]" "INFO" ""
        WriteLog "Firmware            [EINK: ${PURPLE}${FirmwareEINKVer}${NC} / ${PURPLE}${FirmwareEINKVerHEX}${NC} (${PURPLE}${FirmwareEINKTime}${NC})]" "INFO" ""
        WriteLog "Software            [${PURPLE}${SoftwareVerBluegiga} ${SoftwareVerCron} ${SoftwareVerDios} ${SoftwareVerHub} ${SoftwareVerLogic} ${SoftwareVerMath} ${SoftwareVerModems} ${SoftwareVerNetmon} ${SoftwareVerPower} ${SoftwareVerSound} ${SoftwareVerUdev}${NC}]" "INFO" ""
        WriteLog "Hardware            [MAK USB / WLAN: [${PURPLE}${MAK_usb} / ${MAK_wlan}${NC}]; UUID nanda / ssd: [${PURPLE}${UUID_nanda} / ${UUID_sda}${NC}]" "INFO" ""
        WriteLog "Hardware UID        [${UID_Hardware}]" "INFO" ""
        #WriteLog "WiFi IP Address     [${PURPLE}--${NC}]" "INFO" ""

	if [ -d "/opt/shturman/upload" ] && [ -d "/opt/shturman/bin/Log" ]
	then
		reportFile="/opt/shturman/bin/Log/BlockReport.log"
		echo "BlockSerialNo=${BlockSerialNo}" > $reportFile
		echo "Hostname=$(hostname)" >> $reportFile
		echo "BlockOrientation=${Orientation}" >> $reportFile
		echo "BaseRoute=${BaseRoute}" >> $reportFile
		echo "CurrentRoute=${CurrentRoute}" >> $reportFile
		echo "MaxRoute=${MaxRoute}" >> $reportFile
		echo "ServersPool=${ServerPool}" >> $reportFile
		echo "PacketInstalled=${ShturmanPacketsListCompact}" >> $reportFile
		echo "ServicesRunning=${ServicesRunning}" | sed 's/ /;/g' >> $reportFile
		echo "ServicesStopped=${ServicesStopped}" | sed 's/ /;/g' >> $reportFile
		echo "ConfigurrationPacket=${ShturmanConfigPacketCompact}" >> $reportFile
		echo "IPAddress=${IPAddreesses}" | sed 's/ /;/g' >> $reportFile
		echo "FirmwareEINKver=${FirmwareEINKVer};${FirmwareEINKTime}" >> $reportFile
		echo "SoftwareVer=BlueGiga:${SoftwareVerBluegigaCompact};Cron:${SoftwareVerCronCompact};Dios:${SoftwareVerDiosCompact};Hub:${SoftwareVerHubCompact};Logic:${SoftwareVerLogicCompact};Math:${SoftwareVerMathCompact};Modems:${SoftwareVerModemsCompact};Netmon:${SoftwareVerNetmonCompact};Power:${SoftwareVerPowerCompact};Sound:$SoftwareVerSoundCompact;Udev:${SoftwareVerUdevCompact}" >> $reportFile
		echo "MAK_usb=${MAK_usb}" >> $reportFile
		echo "MAK_wlan=${MAK_wlan}" >> $reportFile
		echo "UUID_nanda=${UUID_nanda}" >> $reportFile
		echo "UUID_sda=${UUID_sda}" >> $reportFile
		echo "UID_Hardware=${UID_Hardware}" >> $reportFile
		echo "ReportDateTime=$(date +"%Y.%m.%d;%H:%M:%S")" >> $reportFile
		echo "EndOfFile=EndOfFile" >> $reportFile	
		cp $reportFile /opt/shturman/upload/BlockReport-$(date +"%y.%m.%d").log
	fi
	#InstructionList=$(wget -O - http://192.168.51.92/blocks/blockreport.php?BlockSerialNo=${CurrentBlockSerialNo} -O /dev/null -o /dev/null)

}

function ServicesAllStop
{
	
	xService "servicestracking" "stop" "/lib/systemd/system/servicestracking.service" $Release 

	if [ -f "$ShturmanIniFile" ]
	then
		xService "shturman" "stop" "/etc/init.d/shturman" $Release # required for upgrade old versions 
	fi

	if [ -f "$Shturman3IniFile" ]
	then
		xService "shturmanbluegiga" "stop" "/etc/init.d/shturmanbluegiga" $Release
		xService "shturmandios" "stop" "/etc/init.d/shturmandios" $Release
		xService "shturmanhub" "stop" "/etc/init.d/shturmanhub" $Release
		xService "shturmanlogic" "stop" "/etc/init.d/shturmanlogic" $Release
		xService "shturmanmath" "stop" "/etc/init.d/shturmanmath" $Release
		xService "shturmanmodems" "stop" "/etc/init.d/shturmanmodems" $Release
		xService "shturmannetmon" "stop" "/etc/init.d/shturmannetmon" $Release
		xService "shturmanudev" "stop" "/etc/init.d/shturmanudev" $Release
		xService "shturmancron" "stop" "/etc/init.d/shturmancron" $Release
		xService "shturmanpower" "stop" "/etc/init.d/shturmanpower" $Release
		xService "shturmansound" "stop" "/etc/init.d/shturmansound" $Release
	fi
}


function ServicesAllStart
{
	
	xService "servicestracking" "start" "/lib/systemd/system/servicestracking.service" $Release 

	if [ -f "$ShturmanIniFile" ]
	then
		xService "shturman" "start" "/etc/init.d/shturman" $Release # required for upgrade old versions 
	fi

	if [ -f "$Shturman3IniFile" ]
	then
		xService "shturmanbluegiga" "start" "/etc/init.d/shturmanbluegiga" $Release
		xService "shturmandios" "start" "/etc/init.d/shturmandios" $Release
		xService "shturmanhub" "start" "/etc/init.d/shturmanhub" $Release
		xService "shturmanlogic" "start" "/etc/init.d/shturmanlogic" $Release
		xService "shturmanmath" "start" "/etc/init.d/shturmanmath" $Release
		xService "shturmanmodems" "start" "/etc/init.d/shturmanmodems" $Release
		xService "shturmannetmon" "start" "/etc/init.d/shturmannetmon" $Release
		xService "shturmanudev" "start" "/etc/init.d/shturmanudev" $Release
		xService "shturmancron" "start" "/etc/init.d/shturmancron" $Release
		xService "shturmanpower" "start" "/etc/init.d/shturmanpower" $Release
		xService "shturmansound" "start" "/etc/init.d/shturmansound" $Release
	fi
}

# Shturman_Functions_END
