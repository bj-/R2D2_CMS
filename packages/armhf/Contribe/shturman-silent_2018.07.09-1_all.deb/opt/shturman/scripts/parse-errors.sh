#!/bin/bash
NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH
# ============================

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

LogFilePath="/opt/shturman/bin/Log"
LogFileName="${LogFilePath}/${ScriptName}_$(date +"%y.%m.%d").log"

#echo $LogFileName

# === Includes ===
source "${ScriptDirPath}/functions.sh"



ErrorsLogDirPath="/opt/shturman/bin/Log"
UploadFromDir="/opt/shturman/upload"

#echo "ls ${ErrorsLogDirPath}/*.Error"

#exit 0

function getErrorFilesList
{
	# Get Error's files and it logs.
	# gzip and place to upload directory
	# remove source files
 
	local xPath="${1}"

	local xCurrentDate=$(date +"%y.%m.%d") 

	local ContinueScript=1 # switch to false when are not require continues

	if [  ! -d "${xPath}" ]
	then
		WriteLog "Path to Errors files [xPath] must be specified" "ERROR" ""
		exit 1 
	fi
	#exit 0	
	local ErrorFilesList="$(ls ${xPath}/*.Error)"
	if [ "$ErrorFilesList" == "" ]
	then
		#WriteLog ""
		WriteLog "*.Error files are not exist" "INFO" ""
		local ContinueScript=0
	fi

	if [ $ContinueScript -eq 1 ]
	then
		for var in $ErrorFilesList
		do
		        local ErrorFileDirPath=`dirname ${var}`
		        local ErrorFileName=`basename ${var}`
		        local ErrorsLogFileNameOriginal="${ErrorFileName/.Error/}.log"
			local ErrorsLogFileNameZip="${ErrorFileName/.Error/}.zip"
			
			#local ErrorsLogFileNameOriginalExist=0

			#echo "=ErrorsLogFileNameOriginal: [$ErrorsLogFileNameOriginal]"
			#echo "=ErrorsLogFileNameZip: [$ErrorsLogFileNameZip]"
			#ls $ErrorFileDirPath
		
			WriteLog "Processing Error file (\$var): [${var}]" "DUMP" ""

			if [ ! -f "$ErrorFileDirPath/$ErrorsLogFileNameOriginal" ]
		        then
				WriteLog "Does not exist \$ErrorFileDirPath/\$ErrorsLogFileNameOriginal [$ErrorFileDirPath/$ErrorsLogFileNameOriginal]" "DUMP" ""
				local ErrorsLogFileNameOriginal=""
				#local ErrorsLogFileNameOriginalExist=1
				WriteLog "Set \$ErrorsLogFileNameOriginal to [<Empty>]" "DUMP" ""
        		fi
        		if [ ! -f "$ErrorFileDirPath/${ErrorsLogFileNameZip}" ]
        		then
				local ErrorsLogFileNameZip=""
        		fi

			#echo "=================================="
		        #echo "ErrorFile:         [$ErrorFileName]"
               		#echo "LogFileName:       [$ErrorsLogFileNameOriginal]"
                	#echo "LogFileName (zip): [${ErrorsLogFileNameZip}]"
			
			#local ArchiveNamePath=
			#cho "tar -czvf ${ErrorsLogDirPath}/${ErrorFileName}.tar.gz -C $ErrorFileDirPath $ErrorFileName $ErrorsLogFileNameOriginal $ErrorsLogFileNameZip"

			local TempFolder=$(mktemp -d) #Temp folder for archived files. so easy to create archive 
			WriteLog "Created \$TempFolder: [$TempFolder]" "DUMP" ""
			#Copy Error filke to temp dir
			#local ErrorFileNameWsTime="$TempFolder/${ErrorFileName/.Error/}_${eTimeOnly//:/-}.Error"
			#echo "====$ErrorFileNameWsTime"
			#cp $var $ErrorFileNameWsTime
			#cp $var $TempFolder
			#ls $TempFolder
			
			if [ "$ErrorsLogFileNameOriginal" != ""  ]
			then
				
				#LogFilelinesNearError=$ErrorFileDirPath/
				
				#cp 

				# grep log near error
				#echo "=== $ErrorFileDirPath/$ErrorsLogFileNameOriginal"
				local ErrorTimes=$(grep -a "^[0-9]\{2\}:[0-9]\{2\}:[0-9]\{2\}.[0-9]\{0,3\}" $var)

				#echo "DUMP \$ErrorTimes: $ErrorTimes"
				#echo "\$(grep \"^[0-9]\{2\}:[0-9]\{2\}:[0-9]\{2\}.[0-9]\{0,3\}\" $var)"				

				WriteLog "Error time \$ErrorTimes : [$ErrorTimes]" "DUMP" ""
				for eVar in $ErrorTimes
				do
					local eTimeOnly="${eVar%.*}"
					local eTimeOnlyMinutes="${eVar%:*}"
					#echo "${eVar%.*}"
					#echo "${eVar%:*}"
					local OutputFile="$TempFolder/${ErrorFileName/.Error/}_${eTimeOnly//:/-}.Error.part.log"
					local ErrorFileNameWsTime="$TempFolder/${ErrorFileName/.Error/}_${eTimeOnly//:/-}.Error"
					#local LastErrorTime=
					WriteLog "Error File Name (ws time as suffix) \$ErrorFileNameWsTime: [$ErrorFileNameWsTime]" "DUMP" ""
					cp $var $ErrorFileNameWsTime
					#ocal partLogMask="${var/.Error/}_Err-*"
					#ocal partLogMask=${partLogMask#*Log/}
					#echo "$OutputFile"
					echo "============================== NEW ERROR  ================================" > $OutputFile 
					echo "Error Time (H:M:S):    [$eTimeOnly]" >> $OutputFile
					echo "Full time:             [${eVar}]" >> $OutputFile
					echo "Erro File name:        [${ErrorFileName}]" >> $OutputFile
					echo "======= Log File on time 1000rows Before and 100 After Error time  =======" >> $OutputFile
					#echo "grep -A 100 -B 1000 \"$eTimeOnly\" $ErrorFileDirPath/$ErrorsLogFileNameOrigieal"
					if grep "$eTimeOnly" $ErrorFileDirPath/$ErrorsLogFileNameOriginal 
					then
						# if log file containt record with seconds... like "grep 18:40:11"
						#grep "$eTimeOnly" $ErrorFileDirPath/$ErrorsLogFileNameOriginal
						echo "== grep by: [${eTimeOnly}]" >> $OutputFile

						#grep "$eTimeOnly" $ErrorFileDirPath/$ErrorsLogFileNameOriginal

						grep -A 100 -B 1000 "^\[$eTimeOnly" $ErrorFileDirPath/$ErrorsLogFileNameOriginal >> $OutputFile
					else 
						# if not. use minutes. like to "grep 18:40"
						#grep "$eTimeOnlyMinutes" $ErrorFileDirPath/$ErrorsLogFileNameOriginal
						echo "== grep by: [${eTimeOnlyMinutes}]" >> $OutputFile
						grep -A 100 -B 1000 "^\[$eTimeOnlyMinutes" $ErrorFileDirPath/$ErrorsLogFileNameOriginal >> $OutputFile
						#grep "$eTimeOnlyMinutes" $ErrorFileDirPath/$ErrorsLogFileNameOriginal
					fi
				
					#grep -A 100 -B 1000 "$eTimeOnly" $ErrorFileDirPath/$ErrorsLogFileNameOriginal >> $OutputFile
					#grep "$eTimeOnly" $ErrorFileDirPath/$ErrorsLogFileNameOriginal 
					#echo "grep \"$eTimeOnly\" $ErrorFileDirPath/$ErrorsLogFileNameOriginal"
					#echo $OutputFile 
					echo "============================ END Error log ===============================" >> $OutputFile

				done
			fi

			#ls $TempFolder
			#echo "=== $partLogMask"
			#exit 0
			#ls $partLogMask	

			# Archive files
			#   With Logs	
			#result=$(tar -czvf ${ErrorsLogDirPath}/${ErrorFileName}.tar.gz -C $ErrorFileDirPath $ErrorFileName $ErrorsLogFileNameOriginal $ErrorsLogFileNameZip )
			#   Only Error file
			#echo "tar -czvf ${ErrorsLogDirPath}/${ErrorFileName}.tar.gz -C $ErrorFileDirPath $ErrorFileName -C $ErrorFileDirPath $partLogMask"
			#local result=$(tar -czvf ${ErrorsLogDirPath}/${ErrorFileName}.tar.gz -C $ErrorFileDirPath $ErrorFileName $ErrorFileDirPath/$partLogMask )
			local ArchiveName="${ErrorFileName/.Error/}_${eTimeOnly//:/-}.Error.tar.gz"
			local result=$(tar -czvf ${ErrorsLogDirPath}/${ArchiveName} -C $TempFolder ./ )
			
			RemoveDir $TempFolder

			if [ -f "${ErrorsLogDirPath}/${ArchiveName}" ]
			then 
				WriteLog "Created archive [${ArchiveName}] with files (orig.names) [$ErrorFileName $ErrorsLogFileNameOriginal $ErrorsLogFileNameZip]" "MESS" ""
				mv ${ErrorsLogDirPath}/${ArchiveName} $UploadFromDir
				# delete original files
				RemoveFile "$var"
			else
				WriteLog "Did not create archive [${ArchiveName}.tar.gz] with files (orig.names) [$ErrorFileName $ErrorsLogFileNameOriginal $ErrorsLogFileNameZip]" "ERROR" ""
			fi

			#echr "$ErrorsLogFileName"
		        #ls
		
		        #UploadFileToServer "${ServerAddress}" "${BlockSerialNo}" "${UploadFromDir}/${var}" "${UplPass}"
		        #echo "${UploadFromDir}/${var}"
		done
	fi


}

getErrorFilesList $ErrorsLogDirPath

function countUniqueRowsInFLogFileByMaskOLD
{
	local mask=${1:-}

	local logFileName="$(ls /opt/shturman/bin/Log/ShturmanCore-$(date +"%y.%m.%d").log)"
	WriteLog "${FUNCNAME[0]}: Get by Mask: [$mask] from file [$logFileName]"

	if [ -f "${logFileName}" ]
	then
	local TempFolder=$(mktemp -d)
		local outputFileName="LogErrorsCount_$(date +"%y.%m.%d")"
		local outputFileTxtPath="${TempFolder}/${outputFileName}.txt"
		local outputFileArcName="$outputFileName.tar.gz"
		#cho "$outputFilePath"
		
		#cat $(ls /opt/shturman/bin/Log/ShturmanCore-*$(date +"%y.%m.%d").log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep "$mask" | sort | uniq -c
		
		#cat ${logFileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep "$mask" | sort | uniq -c > $outputFileTxtPath

		#cat $(ls /opt/shturman/bin/Log/ShturmanCore-*$(date +"%y.%m.%d").log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -E "WRN:|ERR:" | sort | uniq -c
		cat ${logFileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -E "$mask" | sort | uniq -c > $outputFileTxtPath

		if [ $(stat --printf="%s" $outputFileTxtPath) -gt 0 ]
		then
			local result=$(tar -czvf ${ErrorsLogDirPath}/${outputFileArcName} -C $TempFolder ./ )

			RemoveDir $TempFolder

                        if [ -f "${ErrorsLogDirPath}/${outputFileArcName}" ]
                        then
                                WriteLog "Created archive [${outputFileArcName}] with errors count" "MESS" ""
                                mv ${ErrorsLogDirPath}/${outputFileArcName} $UploadFromDir
                                # delete original files
                                #emoveFile "$var"
                        else
                                WriteLog "Did not create archive [${outputFileArcName}]" "ERROR" ""
                        fi
			#echo "dddd"
		fi
		
		#at $outputFileTxt
		#ls  -l $UploadFromDir

	fi
	#echo "==$mask=="
}

##countUniqueRowsInFLogFileByMask "WRN:|ERR:"
#countUniqueRowsInFLogFileByMask



function countUniqueRowsInFLogFileByMask
{
	local mask=${1:-}

	# 
	local logFileName="$(ls /opt/shturman/bin/Log/ShturmanCore-$(date +"%y.%m.%d").log)"
	WriteLog "${FUNCNAME[0]}: Get by Mask: [$mask] from file [$logFileName]"

	if [ -f "${logFileName}" ]
	then
		local outputFileName="LogErrorsCount_$(date +"%y.%m.%d")"
		local outputFileTxtPath="/opt/shturman/bin/Log/${outputFileName}.log"
		
		# get content and create compiled file
		cat ${logFileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -E "$mask" | sort | uniq -c > $outputFileTxtPath

                if [ -f "${outputFileTxtPath}" ]
                then
                        WriteLog "Created [${outputFileTxtPath}] with errors count" "MESS" ""
                else
                        WriteLog "Did not create [${outputFileTxtPath}]" "ERROR" ""
                fi

	fi
	
	# Move *.zip (yerterday and early created) to upload directory
	mv $(ls /opt/shturman/bin/Log/LogErrorsCount*.zip) /opt/shturman/upload/

}

#countUniqueRowsInFLogFileByMask "WRN:|ERR:|00002"
#countUniqueRowsInFLogFileByMask

exit 0
