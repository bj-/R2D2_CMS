#!/bin/bash
NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"
# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

LogFilePath="/opt/shturman/bin/Log"
LogFileName="${LogFilePath}/${ScriptName}_$(date +"%y.%m.%d").log"

UploadFromDir="/opt/shturman/upload"

source "${ScriptDirPath}/functions.sh"

# ===============================================================

# Repair all problems on the block



# Step A. stop services
# tracking service as firts
WriteLog "Stopping All services" "INFO" ""

# Shturman services
xService "servicestracking" "stop" "/lib/systemd/system/servicestracking.service"
xService "shturman" "stop" "/etc/init.d/shturman"



# Repair problems

# Problem 1. - Big Queue
WriteLog "Remove all *.queue files and put it in to upload folder" "INFO" ""
ls -l /opt/shturman/bin
mv /opt/shturman/bin/*.Queue /opt/shturman/upload/
rm /opt/shturman/bin/Hub.Queue
ls -l /opt/shturman/bin

# start services
# by service tracker
xService "servicestracking" "start" "/lib/systemd/system/servicestracking.service"


# Spet Z:
# Report block configuration
ReportBlockConfiguration

