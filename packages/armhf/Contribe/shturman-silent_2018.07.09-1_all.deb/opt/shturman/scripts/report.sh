#!/bin/bash

param1="${1:-}"

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

# === Includes ===
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"
#echo "source \"${ScriptDirPath}/functions-shturman.sh\""

isAdm

Release=1
if [ -f "/etc/ShturmanDemoInstall.txt" ]
then
        Release=0
fi

report="$(BlockConfigurationReportData)"

echo $report

