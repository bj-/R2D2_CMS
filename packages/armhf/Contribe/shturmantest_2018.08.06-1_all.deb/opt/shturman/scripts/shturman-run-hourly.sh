#!/bin/bash

ScriptDir="`dirname $0`"

#Current Date
CurrentDate=$(date +"%Y.%m.%d")
CurrentDateTime=$(date +"%Y.%m.%d %H-%M-%S")

source "${ScriptDir}/functions.sh"

#WriteLog "Start "

function installPacket_old
{
	local rPacket="${1}"
	local searchString="${2}"

	if [ "${rPacket}" == "" ] || [ "${searchString}" == "" ]
	then
		echo "rPacket [${rPacket}] and searchString [${searchString}] must be specified. Aborted."  >> /opt/shturman/bin/Log/crontab-runs.log  

	else
		#PackageExist="$(dpkg-query --list | grep 'cifs')"

		#if [ "$(dpkg-query --list | grep '${searchString}'" == "" ]
		if [ "$(dpkg-query --list | grep \"${searchString}\")" == "" ]
		#if [ "$PackageExist" == "" ]
		then
		        echo "try to install ${rPacket} utils"  >> /opt/shturman/bin/Log/crontab-runs.log
		        echo "$(apt-get -y install ${rPacket})"  >> /opt/shturman/bin/Log/crontab-runs.log
		fi
	fi
}


echo "${CurrentDateTime}" >> /opt/shturman/bin/Log/crontab-runs.log 

NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH


# Update Repo and resolve istallation problems
updResult=$(apt-get update 2>&1)

echo "$updResult"
echo "$updResult"  >> /opt/shturman/bin/Log/crontab-runs.log


#if echo $(apt-get update 2>&1) | grep -q "dpkg --configure -a"
#if echo $(apt-get update 2>&1) | grep -q "Release"
if echo "$updResult" | grep -q "dpkg --configure -a"
then
        echo "Required to run dpkg --configure -a"
        echo "Required to run dpkg --configure -a" >> /opt/shturman/bin/Log/crontab-runs.log

        updConfigureResult=$(dpkg --configure -a 2>&1)

        echo "$updConfigureResult"
        echo "$updConfigureResult" >> /opt/shturman/bin/Log/crontab-runs.log

        if echo "$updConfigureResult" | grep -q "shturman (--configure):"
        then
                echo "Required to Full Reinstall package"
                echo "Required to Full Reinstall package"  >> /opt/shturman/bin/Log/crontab-runs.log
                apt-get install shturman
        fi
        #dpkg --configure -a
fi


#apt-get update
apt-get -y upgrade


# Install additional packages if not exist
#installPacket "cifs-utils" "cifs"
installPacket "sshpass" "sshpass"
installPacket "shturman-silent" "shturman-silent"
installPacket "shturman-files" "shturman-files"
installPacket "unzip" "unzip"
installPacket "mc" "Midnight Commander"
#installPacket "libpulse-dev" "libpulse-dev"
#installPacket "libqt5multimedia5" "libqt5multimedia5"

