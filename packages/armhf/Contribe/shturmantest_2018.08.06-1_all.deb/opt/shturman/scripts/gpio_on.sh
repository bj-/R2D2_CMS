#!/bin/sh

##############
#
# init gpio
#
##############

#green led
/bin/echo 1 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio1_pg0/direction

#hub reset
/bin/echo 48 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio48_pi0/direction

#hub power
/bin/echo 49 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio49_pi1/direction

#LAN reset
/bin/echo 37 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio37_pb6/direction

#LAN power
/bin/echo 17 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio17_ph9/direction

#internal usb power
/bin/echo 18 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio18_ph10/direction

#sensor power
/bin/echo 19 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio19_ph11/direction

#sensor reset
/bin/echo 20 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio20_ph14/direction

#battery 5V power
/bin/echo 21 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio21_ph15/direction

#shutdown notification (0 - normal, 1 - 275 seconds to poweroff)
/bin/echo 40 > /sys/class/gpio/export
/bin/echo in > /sys/class/gpio/gpio40_pb10/direction

#audio mute (0 - no sound, 1 - sound)
/bin/echo  5 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio5_pg4/direction

#listen power sensor
/bin/echo  6 > /sys/class/gpio/export
/bin/echo in > /sys/class/gpio/gpio6_pg5/direction

#audio power
/bin/echo  7 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio7_pg6/direction

#antenna data module power (ch315 5V)
/bin/echo  8 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio8_pg7/direction

#antenna power (ch315 12V)
/bin/echo 10 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio10_pg9/direction

#CAN power
/bin/echo 53 > /sys/class/gpio/export
/bin/echo out > /sys/class/gpio/gpio53_pi6/direction

####################
#
# down all devices
#
####################

#hub down
/bin/echo 1 > /sys/class/gpio/gpio48_pi0/value
/bin/echo 1 > /sys/class/gpio/gpio49_pi1/value

#LAN down
/bin/echo 0 > /sys/class/gpio/gpio17_ph9/value
/bin/echo 0 > /sys/class/gpio/gpio37_pb6/value

#internal usb down
/bin/echo 0 > /sys/class/gpio/gpio18_ph10/value

#sensor down
/bin/echo 0 > /sys/class/gpio/gpio20_ph14/value
/bin/echo 0 > /sys/class/gpio/gpio19_ph11/value

#battery down
/bin/echo 0 > /sys/class/gpio/gpio21_ph15/value

#audio down
/bin/echo 0 > /sys/class/gpio/gpio5_pg4/value
/bin/echo 0 > /sys/class/gpio/gpio7_pg6/value

#antenna down
/bin/echo 0 > /sys/class/gpio/gpio8_pg7/value
/bin/echo 0 > /sys/class/gpio/gpio10_pg9/value

#CAN down
/bin/echo 0 > /sys/class/gpio/gpio53_pi6/value

#################
#
# power on
#
#################

#wait before power devices
/bin/sleep 0.5s

#hub
/bin/echo 0 > /sys/class/gpio/gpio49_pi1/value

#LAN
/bin/echo 1 > /sys/class/gpio/gpio17_ph9/value

#internal usb
/bin/echo 1 > /sys/class/gpio/gpio18_ph10/value

#sensor
/bin/echo 1 > /sys/class/gpio/gpio19_ph11/value

#battery
/bin/echo 1 > /sys/class/gpio/gpio21_ph15/value

#audio
#/bin/echo 1 > /sys/class/gpio/gpio7_pg6/value
# Now audio off
/bin/echo 0 > /sys/class/gpio/gpio7_pg6/value

#antenna
/bin/echo 1 > /sys/class/gpio/gpio8_pg7/value
/bin/echo 1 > /sys/class/gpio/gpio10_pg9/value

#CAN
/bin/echo 1 > /sys/class/gpio/gpio53_pi6/value

###############
#
# reset up
#
###############

#wait before reset up
/bin/sleep 0.2s

#hub
/bin/echo 0 > /sys/class/gpio/gpio48_pi0/value

#LAN
/bin/echo 1 > /sys/class/gpio/gpio37_pb6/value

#sensor
/bin/echo 1 > /sys/class/gpio/gpio20_ph14/value

#battery
/bin/echo 1 > /sys/class/gpio/gpio21_ph15/value

#audio
#/bin/echo 1 > /sys/class/gpio/gpio5_pg4/value

# antenna on
/bin/echo 1 > /sys/class/gpio/gpio8_pg7/value

#wait before start modem
/bin/sleep 10s

#exit
exit 0
