#!/bin/bash

param1="${1:-}"

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

# === Includes ===
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"
#echo "source \"${ScriptDirPath}/functions-shturman.sh\""

# run as root
isAdm

Release=1 
if [ -f "/etc/ShturmanDemoInstall.txt" ]
then
        Release=0
fi


echo " "
echo " "
echo "========================================================"
echo "          Shturman Configuration script                 "
echo "========================================================"
echo " "
echo "  Usage:"
echo "      [Enter]  - type default value"
echo "      [Ctrl-C] - Exit"
echo " "
# Show curent configuration
WriteLog "===  Current Configuration ===" "INFO" ""
BlockConfigurationReport



if [ -f "$Shturman3IniFile" ]
then
	BlockSerialNo="$(ini_get_parameter_value "${Shturman3IniFile}" "Hub" "Alias")"
        Orientation="$(ini_get_parameter_value "${Shturman3IniFile}" "Dios" "Orientation")"
        #local ServerPool="$(ini_get_parameter_value "${Shturman3IniFile}" "HubBridge.Pool" "Gate01")"

	#WriteLog "!!!!!!!!!!!!!!!  SHTURMAN MULTICORE VERSION ARE NOT SUPPORTED NOW !!!!!!!!!!!!!!!!" "ERROR" "RED" 
	#exit 1
elif [ -f "$ShturmanIniFile" ]
then
	BlockSerialNo="$(ini_get_parameter_value "${ShturmanIniFile}" "Hub" "BlockSerialNo")"
        Orientation="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "Orientation")"
        #local ServerPool="$(ini_get_parameter_value "${ShturmanIniFile}" "Hub" "Host")"
	#local ServerName="$(ini_get_parameter_value "${ShturmanIniFile}" "NetworkMonitor" "ServerName")"
	#local BaseRoute="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "BaseRoute")"
	#local MaxRoute="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "MaxRoute")"
	#local CurrentRoute="$(ini_get_parameter_value "${ShturmanIniFile}" "EInk" "CurrentRoute")"
fi

if [ "$param1" != "" ]
then
	WriteLog "No action required. exit." "INFO" ""
	exit 0
fi


echo " "
echo " "
WriteLog "Please specify block parameters, or press ENTER for default values, or Ctrl-C to Exit" "INFO" ""

#WriteLog "Enter full Block Serail No (like to [STB08626] or [STB10252] or [STB], Default:[STB0001]" "INFO" ""
#read -ep "$(echo -en ${PURPLE}Block Serail No${NC}) (like to [$(echo -en ${WHITE}STB08626${NC})], by Default will keep current:[$(echo -en ${WHITE}${BlockSerialNo}${NC})]): " nBlockSerialNo
read -ep "$(echo -en "${PURPLE}Block Serail No${NC} like to [${WHITE}STB08626${NC}], by Default will keep current:[${WHITE}${BlockSerialNo}${NC}]"): " nBlockSerialNo

#WriteLog "Enter Block Orientation : [1] - cable from down side; [2] cable from upper side, Default=1" "INFO" ""
#read -ep "$(echo -en ${PURPLE}BOVI Orientation${NC}) ([$(echo -en "${WHITE}1 (true)${NC}")] - cable from $(echo -en "${WHITE}down${NC}") side; [$(echo -en "${WHITE}2${NC} (false)")] cable from $(echo -en "${WHITE}upper${NC}") side, Default (current)=$(echo -en "${WHITE}${Orientation}${NC}")): " BOVIOrientation
#read -ep "$(echo -en "${PURPLE}BOVI Orientation${NC} ([${WHITE}1 (true)${NC}] - cable from ${WHITE}down${NC} side; [${WHITE}2 (false)${NC})] cable from ${WHITE}upper${NC} side, Default (current)=${WHITE}${Orientation}${NC}"): " BOVIOrientation
echo -en "${PURPLE}BOVI Orientation${NC} ([${WHITE}1 (true)${NC}] - cable from ${WHITE}down${NC} side; [${WHITE}2 (false)${NC})] cable from ${WHITE}upper${NC} side, Default (current)=${WHITE}${Orientation}${NC}"
read -ep ": " BOVIOrientation

#WriteLog "Enter Server Address and port: Default:[192.168.51.88:45796]" "INFO" ""
#read -p "ServerAddress: " ServerAddress

if [ "${nBlockSerialNo}" == "" ]
then
	nBlockSerialNo="${BlockSerialNo}"
fi

if [ "${BOVIOrientation}" == "" ]
then
	BOVIOrientation="${Orientation}"
fi


#echo "BlockSerialNo [${BlockSerialNo}]"
#echo "BOVI Orientation   [${BOVIOrientation}]"
#echo "ServerAddress  [${ServerAddress}]"

# Stop Service
xService "servicestracking" "stop" "/lib/systemd/system/servicestracking.service" $Release
#xService "shturman" "stop" "/etc/init.d/shturman" $Release
#xService "shturmnan" "stop"

# Deploy new cfg

if [ "${BOVIOrientation}" == "true" ] || [ "${BOVIOrientation}" == "1" ]
then 
	BOVIOrientation="true"
else
	BOVIOrientation="false"
fi


if [ -f "$Shturman3IniFile" ]
then
	xService "shturmanhub" "stop" "/etc/init.d/shturmanhub" $Release
	xService "shturmandios" "stop" "/etc/init.d/shturmandios" $Release
	ini_change_parameter "/opt/shturman/bin/Shturman3.ini" "Hub" "Alias=" "${nBlockSerialNo}"
	ini_change_parameter "/opt/shturman/bin/Shturman3.ini" "Dios" "Orientation=" "${BOVIOrientation}"
	xService "shturmanhub" "start" "/etc/init.d/shturmanhub" $Release
	xService "shturmandios" "start" "/etc/init.d/shturmandios" $Release
elif [ -f "$ShturmanIniFile" ]
then
	xService "shturman" "stop" "/etc/init.d/shturman" $Release
	ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialNo=" "${nBlockSerialNo}"
	ini_change_parameter "/opt/shturman/bin/Shturman.ini" "EInk" "Orientation=" "${BOVIOrientation}"
	xService "shturman" "start" "/etc/init.d/shturman" $Release
fi

set_hostname "$nBlockSerialNo"

# Start Shturman Service
#xService "shturmnan" "start"
#xService "shturman" "start" "/etc/init.d/shturman" $Release
xService "servicestracking" "start" "/lib/systemd/system/servicestracking.service" $Release

# Report Config

WriteLog "===  Deployed Configuration ===" "INFO" ""
BlockConfigurationReport

exit 0
