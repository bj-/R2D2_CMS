#!/bin/bash

REBOOT_SENSOR=/sys/class/gpio/gpio40_pb10/value
A20_ALIVE=/sys/class/gpio/gpio21_ph15/value
GREEN_LED=/sys/class/gpio/gpio1_pg0/value
ANTENNA=/sys/class/gpio/gpio8_pg7/value

function set_gpio_on_exit
{
  /bin/echo 0 > ${GREEN_LED}
  /bin/echo 0 > ${A20_ALIVE}
  /bin/echo 0 > ${ANTENNA}
}

function finish
{
  /usr/bin/sudo /bin/sh -c '/bin/echo "Prepare shutdown $(/bin/date)" >> /opt/shturman/bin/Log/PowerMonitor-$(/bin/date +%y.%m.%d).log'
  /bin/sleep 10s

  set_gpio_on_exit
  /usr/bin/sudo /bin/sh -c '/bin/echo "Shutdown $(/bin/date)" >> /opt/shturman/bin/Log/PowerMonitor-$(/bin/date +%y.%m.%d).log'

  exit 0
}

#trap system signals to finish correctly
trap finish SIGTERM SIGINT SIGABRT

/bin/echo POWERMONITOR STARTED

#init GPIO
PATH=`dirname $0`
${PATH}/gpio_on.sh

#start monitoring
/usr/bin/sudo /bin/sh -c '/bin/echo "Start $(/bin/date)" >> /opt/shturman/bin/Log/PowerMonitor-$(/bin/date +%y.%m.%d).log'

while true; do

  #reset "watchdog" timer
  /bin/echo 0 > ${A20_ALIVE}
  /bin/sleep 0.1s
  /bin/echo 1 > ${A20_ALIVE}

  /bin/sleep 2s

done
