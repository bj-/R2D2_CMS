#!/bin/bash


exit 0

NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

LogFilePath="/opt/shturman/bin/Log"
LogFileName="${LogFilePath}/${ScriptName}_$(date +"%y.%m.%d").log"

#echo $LogFileName

# === Includes ===
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"

# run as root
isAdm

Release=1
if [ -f "/etc/ShturmanDemoInstall.txt" ]
then
        Release=0
fi

ShturmanIniFile="/opt/shturman/bin/Shturman.ini"
Shturman3IniFile="/opt/shturman/bin/Shturman3.ini"
BackupFileName="/opt/shturman/bin/Shturman.ini.storeparams"
Backup3FileName="/opt/shturman/bin/Shturman3.ini.storeparams"
LogFilePath="/opt/shturman/bin/Log"

firmwareFolderPath="/opt/shturman/firmware"

# ===========================

# check firmware version
requireUpdate=0
perviousFW=""

if [ -f "${firmwareFolderPath}/fwflag.txt" ]
then
	perviousFW="$(cat "${firmwareFolderPath}/fwflag.txt")"
fi
currentFW="$(ls ${firmwareFolderPath}/*.bin)"

if [ "$perviousFW" != "$currentFW" ]
then
	requireUpdate=1
fi

#if [ ! -f "${firmwareFolderPath}/fwflag.txt" ]
#then
#	requireUpdate=1
#fi

#echo "$requireUpdate"
#exit

if [ $requireUpdate -eq 1 ]
then
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/shturman/lib
	# Stop all services
	ServicesAllStop
	# unload module ftdi_sio
	rmmod ftdi_sio
	# run Updater
	
	$firmwareFolderPath/Updater $firmwareFolderPath $LogFileName
	WriteLog "run: [${firmwareFolderPath}/Updater ${firmwareFolderPath} ${LogFileName}]" "INFO" ""

	# reload module ftdi_sio
	modprobe ftdi_sio
	#start all services
#	ServicesAllStart

	#ls ${firmwareFolderPath}*.bin > ${firmwareFolderPath}/fwflag.txt
	ls ${firmwareFolderPath}/*.bin > ${firmwareFolderPath}/fwflag.txt

	cp $LogFileName /opt/shturman/upload/

	WriteLog "REBOOT block." "INFO" ""

	reboot

fi 




