#!/bin/bash
NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH
# ============================

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

LogFilePath="/opt/shturman/bin/Log"
LogFileName="${LogFilePath}/${ScriptName}_$(date +"%y.%m.%d").log"

#echo $LogFileName

# === Includes ===
source "${ScriptDirPath}/functions.sh"

ErrorsLogDirPath="/opt/shturman/bin/Log"
UploadFromDir="/opt/shturman/upload"

log="$1"



if [ "${log}" == "a" ] || [ "${log}" == "hub" ]
then
	writeToFfile="/opt/shturman/bin/Log/LogsLinesCountAll_$(date +"%y.%m.%d").log"

	echo "Log Full Statistics from $date" > $writeToFfile
	echo -e "\n\nShturman Hub:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanHub-$(date +"%y-%m-%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"

	echo -e "\n\nShturman Core:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanCore-$(date +"%y.%m.%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"
	#cat $(ls /opt/shturman/bin/Log/ShturmanC*.log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "пакет" | sort | uniq -c

	echo -e "\n\nShturman Dios:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanDios-$(date +"%y-%m-%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"
	#cat $(ls /opt/shturman/bin/Log/ShturmanD*.log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "пакет" | sort | uniq -c

	echo -e "\n\nShturman Logic:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanLogic-$(date +"%y-%m-%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"
	#cat $(ls /opt/shturman/bin/Log/ShturmanL*.log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "пакет|екущее" | sort | uniq -c

	echo -e "\n\nShturman Modem:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanModems-$(date +"%y-%m-%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"
	#cat $(ls /opt/shturman/bin/Log/ShturmanM*.log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "пакет" | sort | uniq -c

	echo -e "\n\nShturman Netmon:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanNetmon-$(date +"%y-%m-%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"
	#cat $(ls /opt/shturman/bin/Log/ShturmanN*.log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "пакет" | sort | uniq -c

	echo -e "\n\nShturman Udev:" >> $writeToFfile
	countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanUdev-$(date +"%y-%m-%d").log" "$writeToFfile" "ERR:|WRN:" "" "1"
	#cat $(ls /opt/shturman/bin/Log/ShturmanU*.log) | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "пакет" | sort | uniq -c

elif [ "${log}" == "h" ] || [ "${log}" == "hub" ]
then
	tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanHub*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "d" ] || [ "${log}" == "dios" ]
then
	tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanDios*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "b" ] || [ "${log}" == "bg" ] || [ "${log}" == "bluegiga" ]
then
        tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanBluegiga*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "c" ] || [ "${log}" == "core" ]
then
        tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanCore*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "l" ] || [ "${log}" == "logic" ]
then
        tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanLogic*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "m" ] || [ "${log}" == "modem" ] || [ "${log}" == "modems" ]
then
        tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanModems*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "n" ] || [ "${log}" == "net" ] || [ "${log}" == "netmon" ]
then
        tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanNetmon*.log) | grep -v -E "ALIVE"
elif [ "${log}" == "u" ] || [ "${log}" == "udev" ]
then
        tail -f -n 100 $(ls /opt/shturman/bin/Log/ShturmanUdev*.log) | grep -v -E "ALIVE"
else
	echo "Run example 
	./script.sh [ h | d | b | c | l | m | n | u ]
	Where [h|d|...] - is first letter from log name
	
	Or 'a' to get all logs statistics"
	echo "=== List Log Files ==="
	echo "$(ls /opt/shturman/bin/Log/Shturman*.log | awk -F"/" '{print $6}')"
fi  
