#!/bin/bash


DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

LogFilePath="/opt/shturman/bin/Log"
LogFileName="${LogFilePath}/${ScriptName}_$(date +"%y.%m.%d").log"

#echo $LogFileName

# === Includes ===
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"

# run as root
isAdm

Release=1
if [ -f "/etc/ShturmanDemoInstall.txt" ]
then
	Release=0
fi

ShturmanIniFile="/opt/shturman/bin/Shturman.ini"
Shturman3IniFile="/opt/shturman/bin/Shturman3.ini"
BackupFileName="/opt/shturman/bin/Shturman.ini.storeparams"
Backup3FileName="/opt/shturman/bin/Shturman3.ini.storeparams"
LogFilePath="/opt/shturman/bin/Log"

# ===========================

action="${1^^}"


if [ "$action" == "STOP" ]
then
	ServicesAllStop

	#xService "servicestracking" "stop" "/lib/systemd/system/servicestracking.service" $Release 

	#if [ -f "$ShturmanIniFile" ]
	#then
	#	xService "shturman" "stop" "/etc/init.d/shturman" $Release # required for upgrade old versions 
	#fi

	#if [ -f "$Shturman3IniFile" ]
	#then
	#	xService "shturmanbluegiga" "stop" "/etc/init.d/shturmanbluegiga" $Release
	#	xService "shturmandios" "stop" "/etc/init.d/shturmandios" $Release
	#	xService "shturmanhub" "stop" "/etc/init.d/shturmanhub" $Release
	#	xService "shturmanlogic" "stop" "/etc/init.d/shturmanlogic" $Release
	#	xService "shturmanmath" "stop" "/etc/init.d/shturmanmath" $Release
	#	xService "shturmanmodems" "stop" "/etc/init.d/shturmanmodems" $Release
	#	xService "shturmannetmon" "stop" "/etc/init.d/shturmannetmon" $Release
	#	xService "shturmanudev" "stop" "/etc/init.d/shturmanudev" $Release
	#	xService "shturmancron" "stop" "/etc/init.d/shturmancron" $Release
	#fi
fi


if [ "$action" == "START" ]
then
	ServicesAllStart
	#xService "servicestracking" "start" "/lib/systemd/system/servicestracking.service" $Release 

	#if [ -f "$ShturmanIniFile" ]
	#then
	#	xService "shturman" "start" "/etc/init.d/shturman" $Release # required for upgrade old versions 
	#fi

	#if [ -f "$Shturman3IniFile" ]
	#then
	#	xService "shturmanbluegiga" "start" "/etc/init.d/shturmanbluegiga" $Release
	#	xService "shturmandios" "start" "/etc/init.d/shturmandios" $Release
	#	xService "shturmanhub" "start" "/etc/init.d/shturmanhub" $Release
	#	xService "shturmanlogic" "start" "/etc/init.d/shturmanlogic" $Release
	#	xService "shturmanmath" "start" "/etc/init.d/shturmanmath" $Release
	#	xService "shturmanmodems" "start" "/etc/init.d/shturmanmodems" $Release
	#	xService "shturmannetmon" "start" "/etc/init.d/shturmannetmon" $Release
	#	xService "shturmanudev" "start" "/etc/init.d/shturmanudev" $Release
	#	xService "shturmancron" "start" "/etc/init.d/shturmancron" $Release
	#fi
fi
