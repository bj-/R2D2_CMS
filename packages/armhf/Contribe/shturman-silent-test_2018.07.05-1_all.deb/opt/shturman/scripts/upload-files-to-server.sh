#!/bin/bash

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

# === Includes ===
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"
#echo "source \"${ScriptDirPath}/functions-shturman.sh\""


UploadFromDir="/opt/shturman/upload" 

ServerAddress="Block@192.168.51.92:/D:/BlockUpload/"
UplPass="Chi79Mai"

NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH

function UploadFileToServer
{
	ServerPath="${1}"
	ServerCreateFolder="${2}"
	UploadFilePath="${3}"
	ServerUserPass="${4}"

	if [ "${ServerPath}" == "" ] || [ "${UploadFilePath}" == "" ] || [ "${ServerUserPass}" == "" ]
	then
		WriteLog "ServerPath [${ServerPath}] and UploadFilePath [${UploadFilePath}] and ServerUserPass [???] must be specified" "ERROR" ""
	else
		# upload files
		export SSHPASS=${ServerUserPass}

		sshpass -e sftp -oStrictHostKeyChecking=no Block@192.168.51.92:/D:/BlockUpload/ << SOMEDELIMITER
        		mkdir ${ServerCreateFolder}
	       		cd ${ServerCreateFolder}
        		put ${UploadFilePath}
        		bye
SOMEDELIMITER
# "SOMEDELIMITER" must be placed at start of line

		#Check uploaded file
		#echo "Chek upload"
		local ChekingFileName=`basename ${UploadFilePath}`
		#echo "$ChekingFileName"
		local LocalFileSize=$(ls -l ${UploadFilePath} | awk '{print $5}')
		local UploadedFileInfo=$(sshpass -e sftp -oStrictHostKeyChecking=no Block@192.168.51.92:/D:/BlockUpload/${ServerCreateFolder}/ << SOMEDELIMITER
			ls -l ./$ChekingFileName 
SOMEDELIMITER
		)
		local UploadedFileSize="$(echo "$UploadedFileInfo" | grep "$ChekingFileName" | grep -v "ls" |awk  '{print $5}' )"
		#UploadedFileInfo=$(echo $UploadedFileInfo | grep "$ChekingFileName") # |awk  '{print $5}')
		#UploadedFileInfo="${UploadedFileInfo#ls}"
		#echo "====="
		#echo "$UploadedFileInfo"
		#echo "$LocalFileInfo"
		#echo "====="
		if [ $LocalFileSize == $UploadedFileSize ]
		then 
			WriteLog "File [$UploadFilePath] uploaded" "MESS" ""
			#TODO remove src file
			rm $UploadFilePath
		else
			WriteLog "File [$UploadFilePath] is not uloaded correctly. local size=[$LocalFileSize] uploaded size=[$UploadedFileSize]" "ERROR" ""
			
		fi
		
	fi
}


if [ -f "$Shturman3IniFile" ]
then
	BlockSerialNo="$(ini_get_parameter_value "${Shturman3IniFile}" "Hub" "Alias")"
elif [ -f "$ShturmanIniFile" ]
then
	BlockSerialNo="$(ini_get_parameter_value "${ShturmanIniFile}" "Hub" "BlockSerialNo")"
	#BlockSerialNo=$(cat /opt/shturman/bin/Shturman.ini | grep "^BlockSerialNo=")
	#BlockSerialNo="${BlockSerialNo#BlockSerialNo=}"
else
	BlockSerialNo="$(hostname)"
fi


for var in $(ls ${UploadFromDir})
do
	UploadFileToServer "${ServerAddress}" "${BlockSerialNo}" "${UploadFromDir}/${var}" "${UplPass}"
	#echo "${UploadFromDir}/${var}"
done


#sshpass -e sftp -oStrictHostKeyChecking=no Block@192.168.51.92:/D:/BlockUpload/ << SOMEDELIMITER 
#        mkdir "${BlockSerialNo}"
#        cd "${BlockSerialNo}"
#        put /home/olimex/python3_3.4.2-2_armhf.deb
#        bye
#SOMEDELIMITER
