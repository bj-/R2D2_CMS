#!/bin/bash
NewPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH=$NewPATH
# ============================

DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"
# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"
#================================================

#ShturmanLogPath="/opt/shturman/bin/Log"
#ShturmanUploadPath=

if [ -f "$Shturman3IniFile" ]
then
        BlockSerialNo="$(ini_get_parameter_value "${Shturman3IniFile}" "Hub" "Alias")"
elif [ -f "$ShturmanIniFile" ]
then
        BlockSerialNo="$(ini_get_parameter_value "${ShturmanIniFile}" "Hub" "BlockSerialNo")"
        #BlockSerialNo=$(cat /opt/shturman/bin/Shturman.ini | grep "^BlockSerialNo=")
        #BlockSerialNo="${BlockSerialNo#BlockSerialNo=}"
else
        BlockSerialNo="$(hostname)"
fi


CurrentBlockSerialNo="$BlockSerialNo"
#CurrentBlockSerialNo=$(ini_get_parameter_value "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialNo")
#CurrentBlockSerialNo=$(getShturmanIniValue "Hub" "^BlockSerialNo=")

#InstructionList=$(wget -O - http://192.168.51.92/blockquery.php?mmBlockSerialNo=${CurrentBlockSerialNo})
#InstructionList=$(wget -O - http://192.168.51.92/blockquery.php?mmBlockSerialNo=${CurrentBlockSerialNo} |
#    sed -e 's/[{}]/''/g' | 
#    awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}')
InstructionList=$(wget -O - http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo})
#InstructionList=$(echo "$InstructionList" | grep -v "##") # remove commets
#InstructionList=$(echo "$InstructionList" | grep -Ev '^$') # remove blank lines
#InstructionList=$(echo "$InstructionList" | sed '/\r/d') # remove blank lines
#InstructionList=$(echo "$InstructionList" | tr -s '\n' '\n') # remove blank lines

RecomendedForceUpload=0 # flag force upload

while read -r line; do
	InstructionId=$(echo $line | awk -F";" '{print $1}')
	Action=$(echo $line | awk -F";" '{print $2}')
	ServiceName=$(echo $line | awk -F";" '{print $3}')
	ServiceLogMask=$(echo $line | awk -F";" '{print $4}')
	ServiceLogArcMask=$(echo $line | awk -F";" '{print $5}')
	Source=$(echo $line | awk -F";" '{print $6}')
	Target=$(echo $line | awk -F";" '{print $7}')
	Parameters=$(echo $line | awk -F";" '{print $8}')
	#echo "xx: [$line]" 

	if [ $DEBUG -eq 1 ]
	then
		echo "+=========================================+"
		echo "InstructionId:     [$InstructionId]"
		echo "Action:            [$Action]"
		echo "ServiceName:       [$ServiceName]"
		echo "ServiceLogMask:    [$ServiceLogMask]"
		echo "ServiceLogArcMask: [$ServiceLogArcMask]"
		echo "Source:            [$Source]"
		echo "Target:            [$Target]"
		echo "Parameters:        [$Parameters]"
		echo "+=========================================+"
	fi

	if [ "$Action" == "" ]
	then
		# do noting 
		echo "No New task"
	elif [ "$Action" == "put:file" ]
	then
		if [ -f "$Source" ]
		then
			#SourceFileName=`basename $Source`
			if [ "${Target}" == "" ]     # in Target fielt is empty - use Source file name
			then
				Target=`basename $Source`
			fi
			TargetArc="${Target}.tar.gz"

			# Check exist archoved file before 
			if [ ! -f "$TargetArc" ]
			then
				# arciving and copy required file to upload dir [and set new name]
				result=$(tar -czvf ${TargetArc} ${Source} )
				mv ${TargetArc} $UploadFromDir/
				#p $Source $UploadFromDir/$Target
				# confirm Operation on server
				result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=DONE&UploadedFileName=${TargetArc}")
			else
				result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=ERROR&Comment=TargetFileAlreadyExist")
			fi
		else
			result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=ERROR&Comment=FileDoesNotExist")
		fi
	elif [ "$Action" == "put:log" ]
	then
		if [ "$ServiceName" == "" ] || [ "$ServiceLogMask" == "" ] || [ "$ServiceLogArcMask" == "" ] || [ "$Parameters" == "" ]
		then
			# some Error
			result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=ERROR&Comment=ArgumentError")
		else
			YY="$(echo ${Parameters} | awk -F"." '{print $1}')"
			MM="$(echo ${Parameters} | awk -F"." '{print $2}')"
			DD="$(echo ${Parameters} | awk -F"." '{print $3}')"
			ServiceLogMask=${ServiceLogMask//YY/${YY}}
			ServiceLogMask=${ServiceLogMask//MM/${MM}}
			ServiceLogMask=${ServiceLogMask//DD/${DD}}
			ServiceLogArcMask=${ServiceLogArcMask//YY/${YY}}
			ServiceLogArcMask=${ServiceLogArcMask//MM/${MM}}
			ServiceLogArcMask=${ServiceLogArcMask//DD/${DD}}
			
			if [ -f "$ShturmanLogPath/$ServiceLogMask" ]
			then
				# Archive and upload
				result=$(tar -czvf ${ShturmanLogPath}/${ServiceLogMask}.tar.gz -C $ShturmanLogPath ${ShturmanLogPath}/${ServiceLogMask} )
				
				if [ -f "${ShturmanLogPath}/${ServiceLogMask}.tar.gz" ]
				then
					mv ${ShturmanLogPath}/${ServiceLogMask}.tar.gz $UploadFromDir
					result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=DONE&UploadedFileName=${ServiceLogMask}.tar.gz")
				else
					result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=ERROR&Comment=CantCreateArchive")
				fi
			elif [ -f "$ShturmanLogPath/$ServiceLogArcMask" ]
			then
				# upload Archived
				mv $ShturmanLogPath/$ServiceLogArcMask $UploadFromDir
				result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=DONE&UploadedFileName=${ServiceLogArcMask}")
			else
				# Does not exist log files
				result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=ERROR&Comment=FileDoesNotExist")
			fi
		fi
		
	else
		result=$(wget -O - "http://192.168.51.92/blocks/blockquery.php?BlockSerialNo=${CurrentBlockSerialNo}&id=${InstructionId}&Result=ERROR&Comment=UncknownActionType")
	fi

	if [ "$Action" != "" ]
	then
		RecomendedForceUpload=1 # flag force upload
	        # force upload result
	fi
	

#BlockSerialNo
#id
#Result
#UploadedFileName
#Comment



done <<< "$InstructionList"


if [ $RecomendedForceUpload -eq 1 ]
then
	# force upload result
	$ScriptDirPath/upload-files-to-server.sh
	WriteLog "Force upload files to server" "INFO"
fi

exit 0
