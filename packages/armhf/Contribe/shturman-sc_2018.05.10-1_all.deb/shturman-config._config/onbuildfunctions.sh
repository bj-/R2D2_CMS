#!/bin/bash

#echo "asdasafasfffffffffffff"

function PacketSpecifiedFilesCopy
{
	# Place here commands used only for compilation this Package 
	# Example:
	#	- Set Rights
	#	- Copy / merge files to/in package 

	#cp ${ScriptPath}/functions.sh ${PackageSourcePath}/opt/shturman/scripts/functions.sh
	#cp ${ScriptPath}/functions.sh ${PackageNewPath}/opt/shturman/scripts/functions.sh
	echo "===="
	#cat ${ScriptPath}/functions.sh > ${PackageNewPath}/opt/shturman/scripts/functions.sh
	RemoveFile ${PackageNewPath}/opt/shturman/scripts/functions.sh	
}

function PacketSpecifiedSetFilesRight
{
	# Set right to paket's files

	# Set Right for files
	chmod 644 ${PackageNewPath}/opt/shturman/conf/shturman-server.conf
	chmod 644 ${PackageNewPath}/opt/shturman/conf/Megafon-APN.conf
	chmod 644 ${PackageNewPath}/opt/shturman/conf/shturman-server-sc.conf

}
