#!/bin/bash

#PACKAGESPECIANFUNCTIONSBEGIN#

# Shtruman Installation package default parameters

ShturmanIniFile="/opt/shturman/bin/Shturman.ini"
Shturman3IniFile="/opt/shturman/bin/Shturman3.ini"
BackupFileName="/opt/shturman/bin/Shturman.ini.storeparams"
Backup3FileName="/opt/shturman/bin/Shturman3.ini.storeparams"

ServerConfigFileSC="/opt/shturman/conf/shturman-server-sc.conf"
ServerConfigFile="/opt/shturman/conf/shturman-server.conf"

LogFilePath="/opt/shturman/bin/Log"
LogFileName="${LogFilePath}/Shturman-config_$(date +"%y.%m.%d").log"


#PACKAGESPECIANFUNCTIONSEND#

