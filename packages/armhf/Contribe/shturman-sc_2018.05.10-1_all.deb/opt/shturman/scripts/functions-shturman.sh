#!/bin/bash

# Shturman_Functions_BEGIN
ShturmanIniFilePath="/opt/shturman/bin/Shturman.ini"
ShturmanLogPath="/opt/shturman/bin/Log"
UploadFromDir="/opt/shturman/upload"

function getShturmanIniProperty
{
	# get any property from Shturman.ini file
	local Section="$1"
	local Property="$2"

	echo $(cat /opt/shturman/bin/Shturman.ini | grep "${Property}" )

}
#getShturmanIniProperty "Hub" "^BlockSerialNo="
#getShturmanIniProperty "EInk" "^Orientation="

function getShturmanIniValue
{
	# get any property from Shturman.ini file
	local Section="$1"
	local Property="$2"

	local iniProperty="$(getShturmanIniProperty "$Section" "$Property")"

	echo "${iniProperty#*=}"

}
#getShturmanIniValue "Hub" "^BlockSerialNo="
#getShturmanIniValue "EInk" "^Orientation="



function BlockConfigurationReport
{
	WriteLog "Configuration Report" "INFO" ""
	WriteLog "Hostname:          [${PURPLE}$(hostname)${NC}]" "INFO" ""
	WriteLog "BlockSerialNo:     [${PURPLE}$(getShturmanIniProperty "Hub" "^BlockSerialNo=")${NC}]" "INFO" ""
	#riteLog "BlockSerialNo:     [${PURPLE}$(sudo cat /opt/shturman/bin/Shturman.ini | grep "^BlockSerialNo=" )${NC}]" "INFO" ""
	WriteLog "Block Orientation: [${PURPLE}$(getShturmanIniProperty "EInk" "^Orientation=")${NC}] (true = cable BOTTOM side / false = cable UP side) " "INFO" ""
	#WriteLog "Block Orientation: [${PURPLE}$(sudo cat /opt/shturman/bin/Shturman.ini | grep "^Orientation")${NC}] (true = cable BOTTOM side / false = cable UP side) " "INFO" ""
        WriteLog "Packets installed: [${PURPLE}$(dpkg-query --list | grep "turman" | awk '{print $2 " ("$3"); " }' | tr -d '\n')${NC}]" "INFO" ""
	#WriteLog "Packets installed: [${PURPLE}$(dpkg-query --list | grep "turman" )${NC}]" "INFO" ""
	WriteLog "Packet Version:    [${PURPLE}--${NC}]" "INFO" ""
	WriteLog "IP Addresses       [${PURPLE}$(hostname -I)${NC}]" "INFO" ""
	#WriteLog "WiFi IP Address    [${PURPLE}--${NC}]" "INFO" ""
}

# Shturman_Functions_END
