#!/bin/bash
#echo " THE =NEW= FUNCTIONS FILE"

DEBUG=0
#
#BEGINCOMMONFUNCTIONS#
#

# Colored Text
# You can use these ANSI escape codes:
# Black        0;30     Dark Gray     1;30
# Red          0;31     Light Red     1;31
# Green        0;32     Light Green   1;32
# Brown/Orange 0;33     Yellow        1;33
# Blue         0;34     Light Blue    1;34
# Purple       0;35     Light Purple  1;35
# Cyan         0;36     Light Cyan    1;36
# Light Gray   0;37     White         1;37
BLACK='\033[0;30m'
RED='\033[0;31m'
GREEN='\033[0;32m'
BROWN='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LGRAY='\033[0;37m'
DGRAY='\033[1;30m'
LRED='\033[1;31m'
LGREEN='\033[1;32m'
YELLOW='\033[1;33m'
LBLUE='\033[1;34m'
LPURPLE='\033[1;35m'
LCYAN='\033[1;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color
#echo -en "-- [ ${RED}ERROR${NC} ] This script must be run as root\n" 


# functions

function RemoveColorsFromString        # remove Colors codes from string. Typ use for writing data to log files.
{
	text="$1"

	text=${text//${BLACK/\\/\\\\}/}
	text=${text//${RED/\\/\\\\}/}
	text=${text//${GREEN/\\/\\\\}/}
	text=${text//${BROWN/\\/\\\\}/}
	text=${text//${BLUE/\\/\\\\}/}
	text=${text//${PURPLE/\\/\\\\}/}
	text=${text//${CYAN/\\/\\\\}/}
	text=${text//${LGRAY/\\/\\\\}/}
	text=${text//${DGRAY/\\/\\\\}/}
	text=${text//${LRED/\\/\\\\}/}
	text=${text//${LGREEN/\\/\\\\}/}
	text=${text//${YELLOW/\\/\\\\}/}
	text=${text//${LBLUE/\\/\\\\}/}
	text=${text//${LPURPLE/\\/\\\\}/}
	text=${text//${LCYAN/\\/\\\\}/}
	text=${text//${WHITE/\\/\\\\}/}
	text=${text//${NC/\\/\\\\}/}
	
	echo "$text"
}

function WriteLog                      # Log Writter 
{
	#
	#   Usage 
	#	WriteLog "info colored when type is info and color is Purple  ===" "info" "purple" 
	#		$1 - Text 
	#		$2 - type info | warn | error | mess | dump
	#		$3 - Color BLACK | RED | GREEN |BROWN | BLUE | PURPLE | CYAN | LGRAY | etc
	#WriteLog "=== Before UnInstall Script ===" "info" "purple"
	local Text="$1"
	local Type="${2^^}"
	local Color="${3^^}"
	local CDate=$(date +"%Y.%m.%d %H:%M:%S")

	local Debug_Enabled=${DEBUG:-0}

	# Set Color by types	
	case $Type in
		"INFO"    ) local TextColor="${WHITE}";;
		"WRN"     ) local TextColor=${YELLOW};;
		"WARN"    ) local TextColor=${YELLOW};;
		"WARNING" ) local TextColor=${YELLOW};;
		"ERR"     ) local TextColor=${RED};;
		"ERROR"   ) local TextColor=${RED};;
		"MESS"    ) local TextColor=${LGREEN};;
		"TRY"     ) local TextColor=${GREEN};;
		"DUMP"    ) local TextColor=${DGRAY};;
		"TEST"    ) local TextColor=${YELLOW};;
		*         ) local TextColor="";;	
	esac
	
	# reset color by color if it specified
	case $Color in
                "BLACK"   ) local TextColor=${BLACK};;
                "RED"     ) local TextColor=${RED};;
                "GREEN"   ) local TextColor=${GREEN};;
                "BROWN"   ) local TextColor=${BROWN};;
                "BLUE"    ) local TextColor=${BLUE};;
                "PURPLE"  ) local TextColor=${PURPLE};;
                "CYAN"    ) local TextColor=${CYAN};;
                "LGRAY"   ) local TextColor=${LGRAY};;
                "DGRAY"   ) local TextColor=${DGRAY};;
                "LRED"    ) local TextColor=${LRED};;
                "LGREEN"  ) local TextColor=${LGREEN};;
                "YELLOW"  ) local TextColor=${YELLOW};;
                "LBLUE"   ) local TextColor=${LBLUE};;
                "LPURPLE" ) local TextColor=${LPURPLE};;
                "LCYAN"   ) local TextColor=${LCYAN};;
                "WHINE"   ) local TextColor=${WHINE};;
		*         ) ;;#local TextColor="";;	
	esac


	#local ConsoleText=""
	if [ "${Type}" != "" ]
	then 
		if [ "${Type}" == "DUMP" ] || [ "${Type}" == "TEST" ]
		then
			if [ "${Type}" == "DUMP" ] && [ ${Debug_Enabled} -eq 1 ]
			then
				# Dump - colored full line
				echo -en "${TextColor}[ ${Type} ] ${Text}${NC}\n"
			elif [ "${Type}" == "TEST" ]
			then
			#else
				#echo ""
				echo -en "${TextColor}[ ${Type} ] ${Text}${NC}\n" 
			fi
		elif [ "${Color}" != "" ]
		then
			echo -en "${TextColor}[ ${Type} ] ${Text}${NC}\n"
		else
#		local AddTypePrefix="[ ${TextColor}${TYPE}${NC} ]"
			echo -en "[ ${TextColor}${Type}${NC} ] ${Text} \n"
		fi
	else 
		echo -en "${TextColor}${Text}${NC}\n"
	fi
	

	# Output text for log file
	#local LogText="${CDate}	${Type^^}	${Text}\n"
	#local LogText="$(RemoveColorsFromString "${CDate} ${Type^^}       ${Text}")\n"
	local LogText="$(RemoveColorsFromString "${Text}")"
	local LogText="${CDate}	${Type^^}	${LogText}"
	
	if [ "${LogFileName}" != "" ] || [ "${LogFilePath}" != "" ]
	then
		#echo "aa"
		if [ ! -d "${LogFilePath}" ]
		then
			#echo "bb"
			CreateDir ${LogFilePath}
		fi
	fi
	#echo "cc"
	if [ "${LogFileName}" != "" ]
	then 
		#echo "echo \"${LogText}\" >> \"${LogFileName}\""
		echo "${LogText}" >> "${LogFileName}"
	elif [ "${LogFilePath}" != "" ]
	then
		#echo "echo \"${LogText}\" >> \"${LogFilePath}/`basename $0`.log\""
		echo "${LogText}" >> "${LogFilePath}/`basename $0`.log"
	else
		#echo "echo \"${LogText}\" >> \"${LogFilePath}/`basename $0`.log\""
		echo "${LogText}" >> "`dirname $0`/`basename $0`.log"	
	fi	
	

	#if [ "${LogFilePath}" == "" ]
	#then
	#	#echo "echo \"${LogText}\" >> \"${LogFilePath}/`basename $0`.log\""
	#	echo "${LogText}" >> "`dirname $0`/`basename $0`.log"	
	#else
	#	echo "echo \"${LogText}\" >> \"${LogFilePath}/`basename $0`.log\""
	#	echo "${LogText}" >> "${LogFilePath}/`basename $0`.log"
	#
	#fi

	#if [ -f "${LogFilePath}" ]
	#then 
	#	$LogText >> $LogFileName
	#fi
}
#DEBUG=0;
#DEBUG=0;
#WriteLog "Test type Line" "TEST" ""
#WriteLog "Error type Line" "ERROR" ""
#WriteLog "Warning type Line" "WARN" ""
#WriteLog "DUMP type Line" "DUMP" ""


function isAdm                         # Check - script run as root
{

	local DEBUG=0;

	#local toContinue=${1:-0}
	
	if [ ${DEBUG} -eq 1 ]
	then
        	echo "================================ echo variables BEGIN ====================================="
        	echo "\$1:                  [${1}]"
        	echo "toContinue:          [${toContinue}]"
		echo "================================  echo variables END  ====================================="
	fi

	#local 
	# Make sure only root can run our script
	if [ "$(id -u)" != "0" ]; then
   		#echo -en "-- [ ${RED}ERROR${NC} ] This script must be run as root\n"
   		WriteLog "{FUNCNAME[0]}: This script must be run as root" "ERROR" ""
		exit 1
		#if [ ${toContinue} -eq 1 ]
		#then
		#	return 1
		#else
		#	exit 1
		#fi
	#else
	#	return 0
	fi	
}
#isAdm 1
#isAdm 0
#isAdm

function ReportToSever                 # TODO upload report to server??? Now it do nothing 
{
	local Text="$1"
}

# remove one file if exist
function RemoveFile                    # remove File/Link if exist
{
	local FILE="$1"
	#FILE="/opt/shturman/lib/libsocketcan.so.2"
	# if it is link
	if [ -L "${FILE}" ]
	then
	        rm $FILE
	fi
	# If it is File
	if [ -f "${FILE}" ]; then
	        rm $FILE
	fi

	if [ -f "${FILE}" ] || [ -L "${FILE}" ]
	then
		WriteLog "${FUNCNAME[0]}: Cant Delete file [${FILE}]" "WARN" ""
	else
		WriteLog "${FUNCNAME[0]}: Deleted file or link [${FILE}]" "DUMP" ""
	fi
}

function RemoveDir                     # remove Directory with all files
{
	local DIRECTORYNAME="$1"

	if [ -d "${DIRECTORYNAME}" ]
	then
		rm -r -d "${DIRECTORYNAME}"
	fi

	if [ ! -d "${DIRECTORYNAME}" ]
        then
                WriteLog "${FUNCNAME[0]}: Removed directory ${DIRECTORYNAME}" "DUMP" ""
	else
		WriteLog "${FUNCNAME[0]}: Can not remove directory ${DIRECTORYNAME}" "ERROR" ""
		exit 1
        fi
}

function CreateDir                     # Create Directory if it not exist 
{
        local DIRECTORYNAME="$1"

	#echo "DIRECTORYNAME: [${DIRECTORYNAME}]"

        if [ ! -d "${DIRECTORYNAME}" ]
        then
                mkdir "${DIRECTORYNAME}"
        	
		# check
		if [ -d "${DIRECTORYNAME}" ]
        	then
               		WriteLog "${FUNCNAME[0]}: Created directory [${DIRECTORYNAME}]" "DUMP" ""
        	else
                	WriteLog "${FUNCNAME[0]}: Can not create directory [${DIRECTORYNAME}]" "ERROR" ""
                	exit 1
        	fi
	else 
		WriteLog "${FUNCNAME[0]}: Directory Already exist [${DIRECTORYNAME}]. Skip creating." "DUMP" ""
        fi

}


function ini_bakup_value               # Store parameters from ini file to other file (valueskeeper)
{
	local FileNameOriginal="$1"
        local FileNameValuesKeeper="$2"
	local Section="$3"	# blank section name ex "Section". 
	local ParamName="$4"	# blank param name ex: "Parameter1". 

        if [ "$FileNameOriginal" == "" ] || [ "${FileNameValuesKeeper}" == "" ] || [ "$ParamName" == "" ]
        then
                #echo -en "[ ${RED}ERROR${NC} ] ini_backup_value: Original ini file [${FileNameOriginal}] and/or parameter [${ParamName}] must be specified \n"
                WriteLog "${FUNCNAME[0]}: Original ini file [${FileNameOriginal}] and/or valuer keeper file [${FileNameValuesKeeper}] and/or parameter [${ParamName}] must be specified" "ERROR" ""
                exit 1
        fi

        if [ ! -f "${FileNameOriginal}" ]
        then
                #echo -en "[ ${RED}ERROR${NC} ] ini_bakup_value: Original ini file does not exist [${FileNameOriginal}] \n"
                WriteLog "${FUNCNAME[0]}: Original ini file does not exist [${FileNameOriginal}]" "ERROR" "" 
                exit 1 
        fi

	#echo "grep -n $FileNameOriginal -e ${Section}"	
	#sed  -n -e '/\['${Section}'\]/,$p' ${FileNameOriginal} 
	#grep $FileNameOriginal -e "\[${Section}\]"
	#grep -i -A 10 "[Hub]"   $FileNameOriginal
        #sed -e '/BlokSerialNo/' ${FileNameOriginal}
	
	# Store parameter in to file
	WriteLog "${FUNCNAME[0]}: Try to store section:parameter [${Section}:${ParamName}] from file [${FileNameOriginal}] to file [${FileNameValuesKeeper}]" "DUMP" ""

	#WriteLog "next command: local ReadValue=\$(grep $FileNameOriginal -e \"${ParamName}\") " "DUMP" ""
	#local ReadValue="$(grep $FileNameOriginal -e "${ParamName}")"
	
	# get poperty with value from specified section (parameter=value)
	local ReadValue="$(cat $FileNameOriginal | sed -nr "/\[${Section}\]/ { :l /^${ParamName}[ ]*=/ { p; q;}; n; b l;}")"

	WriteLog "${FUNCNAME[0]}: Read from [$FileNameOriginal] - [${ReadValue}] " "DUMP" ""

	if [ "$ReadValue" != "" ]
	then
		ReadValue="${Section}=${ReadValue}"
		WriteLog "${FUNCNAME[0]}: Try to store [${ReadValue}] in [$FileNameValuesKeeper]] " "DUMP" ""
		echo "${ReadValue}" >> $FileNameValuesKeeper
	else
		WriteLog "${FUNCNAME[0]}: Does not found [${ParamName}] in section [${Section}] in [$FileNameValuesKeeper]] " "DUMP" ""
	fi
}
#ini_bakup_value "/opt/shturman/bin/Shturman.ini" "/opt/shturman/bin/Shturman.ini.kt" "Hub" "Host"
#ini_bakup_value "/opt/shturman/bin/Shturman.ini" "/opt/shturman/bin/Shturman.ini.kt" "Hub" "Host"
#ini_bakup_value "/opt/shturman/bin/Shturman.ini" "/opt/shturman/bin/Shturman.ini.kt" "Hub" "Alias"
#ini_bakup_value "/opt/shturman/bin/Shturman.ini" "/opt/shturman/bin/Shturman.ini.kt" "NetworkMonitor" "ServerName"
#ini_bakup_value "/opt/shturman/bin/Shturman.ini" "/opt/shturman/bin/Shturman.ini.kt" "Hub" "Host"
#cat "/opt/shturman/bin/Shturman.ini.kt"
#rm "/opt/shturman/bin/Shturman.ini.kt"

#real migrate
#ShturmanIniFile="/opt/shturman/bin/Shturman.ini"
#Shturman3IniFile="/opt/shturman/bin/Shturman3.ini"
#BackupFileName="/opt/shturman/bin/Shturman.ini.storeparams"
#Backup3FileName="/opt/shturman/bin/Shturman3.ini.storeparams"
#ini_bakup_value "/opt/shturman/bin/Shturman.ini" "/opt/shturman/bin/Shturman.ini.storeparams" "Hub" ""
#ini_bakup_value "$ShturmanIniFile" "$BackupFileName" "Hub" "^BlockSerialNo"
#ini_bakup_value "$ShturmanIniFile" "$BackupFileName" "Hub" "^Host"
#ini_bakup_value $ShturmanIniFile $BackupFileName "NetworkMonitor" "^ServerName"
#ini_bakup_value $ShturmanIniFile $BackupFileName "EInk" "^Orientation"
#ini_bakup_value $ShturmanIniFile $BackupFileName "EInk" "^CurrentRoute"
#cat "$BackupFileName"
#rm "$BackupFileName"

function ini_get_parameter_value
{
	local FileName="$1"
        local Section="$2"
        local ParamName="$3"
        #local Value="$4"

        local DEBUG=0;
        if [ ${DEBUG} -eq 1 ]
        then
                echo "================================ echo variables BEGIN ====================================="
                echo "FileName:         [${FileName}]"
                echo "Section:          [${Section}]"
                echo "ParamName:        [${ParamName}]"
                echo "Value:            [${Value}]"
                echo "================================  echo variables END  ====================================="
        fi

        if [ "$FileName" == "" ] || [ "$ParamName" == "" ]
        then
                WriteLog "${FUNCNAME[0]}: Ini file [${FileName}], Section [${Section}] and parameter [${ParamName}] must be specified" "ERROR" ""
                exit 1
        fi

        if [ ! -f "${FileName}" ]
        then
                WriteLog "${FUNCNAME[0]}: Ini file does not exist [${FileNameOriginal}]" "ERROR" ""
                exit 1
        fi

	
	# get poperty with value from specified section (parameter=value)
	local readParam="$(cat $FileName | sed -nr "/^\[${Section}\]/ { :l /^${ParamName}[ ]*=/ { p; q;}; n; b l;}")"
	# get value only from specified section and parameter
	local readValue="$(cat $FileName | sed -nr "/^\[${Section}\]/ { :l /^${ParamName}[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}")" 
	#local readParam=$(cat ${FileName} | grep "${ParamName}")
	#local readValue=$(echo "$readParam" | awk -F"=" '{print $2}')

        #sed -i "s/${ParamName}.*/${Value}/" ${FileName}
	#d -i "s/${ParamName}.*/${ParamName}${Value}/" ${FileName}

	if [ "$readParam" != "" ]
	then 
		echo "$readValue"
        	WriteLog "${FUNCNAME[0]}: Readed value [${readValue}] of parameter [${ParamName}] from section [${Section}] in file [${FileName}]" "DUMP" ""
	else 
        	WriteLog "${FUNCNAME[0]}: Can not read value [${readValue}] of parameter [${ParamName}] from section [${Section}] in file [${FileName}]" "DUMP" ""
        	echo "NOT_AVAILABLE"
	fi
}
#ini_get_parameter_value "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialNo="
#ini_get_parameter_value "/opt/shturman/bin/Shturman.ini" "Hub" "Alias"
#ini_get_parameter_value "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialo=" 
#ini_get_parameter_value "/opt/shturman/bin/Shturman2.ini" "Hub" "BlockSerialNo=" 
#ini_get_parameter_value "/opt/shturman/bin/Shturman2.ini" "Hub"  
#ini_get_parameter_value "/opt/shturman/bin/Shturman2.ini" 
#ini_get_parameter_value  


function ini_change_parameter          # change any parameter in ini file (by Parameter Name. !!! Section is ignored. TODO )
{
        local FileName="$1"
        local Section="$2"
        local ParamName="${3/=/}"
	local Value="$4"
        local ParamNameNew="${5/=/}"
	if [ "${ParamNameNew}" == "" ]
	then 
		ParamNameNew=$ParamName 
	fi

	#local DEBUG=0;
	if [ ${DEBUG} -eq 1 ]
	then
        	echo "================================ echo variables BEGIN ====================================="
        	echo "FileName:         [${FileName}]"
        	echo "Section:          [${Section}]"
        	echo "ParamName:        [${ParamName}]"
        	echo "ParamNameNew:     [${ParamNameNew}]"
        	echo "Value:            [${Value}]"
		echo "================================  echo variables END  ====================================="
	fi

        if [ "$FileName" == "" ] || [ "$ParamName" == "" ]
        then
                WriteLog "${FUNCNAME[0]}: Ini file [${FileName}], Section [${Section}] and parameter [${ParamName}] must be specified" "ERROR" ""
                exit 1
        fi

        if [ ! -f "${FileName}" ]
        then
                WriteLog "${FUNCNAME[0]}: Ini file does not exist [${FileNameOriginal}]" "ERROR" ""
                exit 1
        fi

	#sed -i "s/${ParamName}.*/${Value}/" ${FileName}
##	sed -i "s/${ParamName}.*/${ParamName}${Value}/" ${FileName}
	sed -i "/^\[${Section}\]$/,/^\[/ s/^${ParamName}=.*/${ParamNameNew}=${Value}/" ${FileName}

	#local ResultRow=$(cat ${FileName} | grep "$ParamName")
	local ResultRow="$(cat $FileName | sed -nr "/^\[${Section}\]/ { :l /^${ParamNameNew}[ ]*=/ { p; q;}; n; b l;}")"
	#echo "local ResultRow=\"\$(cat $FileName | sed -nr \"/^\[${Section}\]/ { :l /^${ParamNameNew}[ ]*=/ { p; q;}; n; b l;}\")\""

	if [ "${ResultRow}" == "${ParamNameNew}=${Value}" ]
	then
		WriteLog "Writed New paramater value [${ResultRow}] in section (may be) [${Section}] in file [${FileName}]" "MESS" ""
	else 
		WriteLog "Can not change paramater. Required [${Section}]=[${ParamNameNew}]=[${Value}] in file [${FileName}] But result is [${ResultRow}]" "ERROR" ""
	fi

}
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialNo=" "NNNAAA24444333"
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "Alias" "NNNAAA24444333"
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "Alias" "Hub" "Fake"
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "Fake" "Hub" "Alias"
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "Alias" "Hub"
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialNo=" 
# got error becouse params are not specified
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" 
#ini_change_parameter "/opt/shturman/bin/Shturman.ini" 
#ini_change_parameter 


function ini_restore_values            # Apply stored parameters to ini file from valueskeeper file (created in func: ini_bakup_value)
{
	# Restore saved values from ini file
	local FileNameOriginal="$1"
        local FileNameValuesKeeper="$2"

	WriteLog "${FUNCNAME[0]}: Restoring ini properties from [${FileNameValuesKeeper}] to [${FileNameOriginal}]" "INFO" ""

        if [ "$FileNameOriginal" == "" ] || [ "" == "${FileNameValuesKeeper}" ]
        then
                #echo -en "[ ${RED}ERROR${NC} ] ini_restore_values: Original and bak ini file [${FileNameOriginal}] and/or [${FileNameValuesKeeper}] must be specified \n"
                WriteLog "${FUNCNAME[0]}: Original and bak ini file [${FileNameOriginal}] and/or [${FileNameValuesKeeper}] must be specified" "ERROR" ""
                exit 1
        fi

        if [ ! -f "${FileNameOriginal}" ]
        then
                #echo -en "[ ${RED}ERROR${NC} ] ini_restore_values: Original or bak ini file does not exist [${FileNameOriginal}] or [${FileNameValuesKeeper}] \n"
                WriteLog "${FUNCNAME[0]}: Target ini file does not exist [${FileNameOriginal}]" "ERROR" ""
                #exit 1 
        elif [ ! -f "${FileNameValuesKeeper}" ]
 	then
		WriteLog "${FUNCNAME[0]}: Bak ini file does not exist [${FileNameValuesKeeper}]. Skip restoring params" "WARN" ""
	else
		WriteLog "${FUNCNAME[0]}: Bak ini file [${FileNameValuesKeeper}]. Containts data:\n$(cat $FileNameValuesKeeper)" "DUMP" ""
		# get stored values from file
		for var in $(cat $FileNameValuesKeeper)
		do
			# extract param name
			local SrcString="${var%=*}="
			local Section=$(echo "${var}" | awk -F"=" '{print $1}')
			local Parameter=$(echo "${var}" | awk -F"=" '{print $2}')
			local Value=$(echo "${var}" | awk -F"=" '{print $3}')
	
			#f [] 
			#echo "------- rod from store -------------"
			#echo "\$Section:   " $Section
			#echo "\$Parameter: " $Parameter
			#echo "\$Value:     " $Value
	
			sed -i "/^\[${Section}\]$/,/^\[/ s/^$Parameter=.*/${Parameter}=${Value}/" "${FileNameOriginal}"
	
			# Change parameter value in ini file  
##			sed -i.tmp 's/'${SrcString}'.*/'${var}'/' ${FileNameOriginal}
			# remove temp file (created by sed)
##			rm "${FileNameOriginal}.tmp" 
		done
	fi
}
#ini_restore_values "/opt/shturman/bin/Shturman3.ini" "/opt/shturman/bin/Shturman3.ini.storeparams"
#ini_restore_values "/opt/shturman/bin/Shturman.ini" "/home/shturman/DepacketBuilder/packet.source.shturman-config-spbmetro3thline/opt/shturman/conf/shturman-server.conf"
#cat /opt/shturman/bin/Shturman.ini | grep -E "BaseRoute|MaxRoute|CurrentRoute|Host|APN|ServerName"

function AddLineToFile                 # Add specified line to file (optionaly create file if not exist; can work in TestMode - no Action; Can add Before specified line)
{
	# Remove lineas my Mask
	# and Add specified line
	local FILE="${1}"		# File full Path
	local MASK="${2}"		# Remove Lines by mask
	local LINE="${3:-}"		# Add lIne to file
	local ACTION="${4:-NotSet}" 		# [CREATE | NotSet] - Create file if not exist
		local ACTION=${ACTION^^}
	local MODE="${5:-Release}" 	# [0 | 1 | TEST | NotSet] - {0 | TEST] - Skip actions. Test Mode
		local MODE=${MODE^^}
	local AddBeforeLine=${6:-}	# Add line before specified line (by sed)

	#echo "=========== INC VARS =========="
	#echo "FILE: [${FILE}]"
	#echo "MASK: [${MASK}]"
	#echo "LINE: [${LINE}]"
	#echo "ACTN: [${ACTION}]"
	#echo "MODE: [${MODE}]"
	#echo "=========== INC VARS =========="

# exit 0	
	if [ "${MODE}" == "0" ] || [ ${MODE} == "TEST" ]
	then
		local MODE="TEST"
	else
		local MODE="RELEASE"
	fi
	

#exit 0

        if [ "$FILE" == "" ]
        then
                WriteLog  "${FUNCNAME[0]}: File [${FILE}] must be specified" "ERROR" ""
                exit 1
        fi
	
	if  [ "$MASK" == "" ] && [ "$LINE" == "" ]
	then
		WriteLog "${FUNCNAME[0]}: Mask [${MASK}] and Line [${LINE}] does not specfied" "WARN" ""
	fi

	# Remove lines by mask if it specified
	if [ "$MASK" != "" ]
	then
		# if MASK is specified
		if [ "${MODE}" != "TEST" ]
               	then
			# if file is exist
			if  [ -f "${FILE}" ]
        		then	
				WriteLog "Try to remove line [${MASK}] from file [${FILE}]" "DUMP" ""
				echo "sed -i.bak \"/${MASK}/d\" ${FILE}"
				sed -i.bak "/${MASK}/d" ${FILE}
				#sed "/${MASK}/d" ${FILE}
				WriteLog "${FUNCNAME[0]}: Remove all lines by mask [${MASK}] in file [${FILE}]" "DUMP" "" 
			else
				WriteLog "${FUNCNAME[0]}: Can not Remove all lines by mask [${MASK}] in file [${FILE}]. File is not exist." "DUMP" ""
			fi
		else
			# different message File is exist or not
			if  [ -f "${FILE}" ]
                        then
				WriteLog "${FUNCNAME[0]}: Skip remove all lines by mask [${MASK}] in file [${FILE}]" "TEST" ""
			else
				WriteLog "${FUNCNAME[0]}: Skip remove all lines by mask [${MASK}] in file [${FILE}]. File is not exist." "TEST" ""
			fi
		fi
	fi

	local LINEADDED=0

	# Add line to file if it specified	
	if [ "$LINE" != "" ]
	then
		if [ "${MODE}" != "TEST" ]
                then
			# different message File is exist or not
			if  [ -f "${FILE}" ]
                        then
				#if [ "${AddBeforeLine}" != "" ]
				#then
				#	sed "/${AddBeforeLine}/i \\${LINE}" ${FILE}
				#else
					#FILE="${ScriptDir}/testconfig.txt"
					#grep -qF "${LINE}" "${FILE}"  || 
					echo "${LINE}" >> ${FILE}
				#fi
				WriteLog "${FUNCNAME[0]}: Try add line [${LINE}] to file [${FILE}]" "DUMP" ""
				local LINEADDED=1 
				# Check
			elif [ ${ACTION} == "CREATE" ]
			then
				echo "${LINE}" >> ${FILE}
                                WriteLog "${FUNCNAME[0]}: Try Create file [${FILE}] and try add line [${LINE}]." "DUMP" ""
				local LINEADDED=1
			else
				WriteLog "${FUNCNAME[0]}: Can not Add line [${LINE}] to file [${FILE}]. File is not exist and Creating not specified." "WARN" ""
			fi
			
			# check
			if [ $LINEADDED -eq 1 ]
			then 
				if [ "$(grep -F "${LINE}" "${FILE}")" == "${LINE}" ]
				then
					WriteLog "${FUNCNAME[0]}: Added [${LINE}] to [${FILE}]" "MESS" ""
				else
					GREPEDLINES="$(grep -F "${LINE}" "${FILE}" | grep -c "^")"
					if [ $GREPEDLINES -gt 1 ]
					then
						WriteLog "${FUNCNAME[0]}: Added duplicate [${LINE}] to [${FILE}]. Grep return [${GREPEDLINES}] rows. Grep Result:" "ERROR" ""
						echo "$(grep -F "${LINE}" "${FILE}")"
					fi
					WriteLog "${FUNCNAME[0]}: Can not add [${LINE}] to [${FILE}]. File listing:" "ERROR" ""
					cat ${FILE}
					exit 1
				fi
			fi 
		else
			# different message File is exist or not
			if  [ -f "${FILE}" ]
                        then
				WriteLog "${FUNCNAME[0]}: Skip Add line [${LINE}] to file [${FILE}]" "TEST" ""
			else
				WriteLog "${FUNCNAME[0]}: Skip Add line [${LINE}] to file [${FILE}]. File is not exist." "TEST" ""
			fi
		fi
	fi
}
#AddLineToFile "/etc/profile" 'PATH=\/opt\/shturman\/scripts:\$PATH && export PATH' 'PATH=/opt/shturman/scripts:$PATH && export PATH' 

function AddLineToFileBeforeLine       # TODO WTF ??? func contain only one "sed" 
{
	

	sed '/export PATH/i \PATH=/opt/shturman/scripts:$PATH' /etc/profile
}


function BackupFile                    # create Bakup copy of file. "${FILE}.shturmanbak"
{
	local FILE="$1"
	local ACTION="${2^^}"
	
	local FILEBACKUP="${FILE}.shturmanbak"
	local CDATE=$(date +"_%Y-%m-%d_%H-%M-%S")
	local FILEBACKUPDEFAULT="${FILEBACKUP}${CDATE}"

        if [ "$FILE" == "" ]
        then
                WriteLog  "${FUNCNAME[0]}: File [${FILE}] must be specified" "ERROR" ""
                exit 1
        fi

	if [ -f "${FILE}" ]
	then
	
		case $ACTION in
			"REPLACE"     ) 
				RemoveFile $FILEBACKUP
				cp $FILE $FILEBACKUP
				if [ -f "${FILEBACKUP}" ]
				then
					WriteLog "${FUNCNAME[0]}: Created BAK file [${FILEBACKUP}] by REPLACE" "DUMP" ""	
				else
					WriteLog "${FUNCNAME[0]}: Can not create BAK file [${FILEBACKUP}] by REPLACE" "WARN" ""
				fi
				;;
			"ONETIME"     )
				if [ -f "${FILEBACKUP}" ]
				then
					WriteLog "${FUNCNAME[0]}: BAK file [${FILEBACKUP}] already exit. No Action Required. by ONETIME." "DUMP" ""	
				else
					#RemoveFile $FILEBACKUP
					cp $FILE $FILEBACKUP
					if [ -f "${FILEBACKUP}" ]
					then
						WriteLog "${FUNCNAME[0]}: Created BAK file [${FILEBACKUP}] by ONETIME" "DUMP" ""	
					else
						WriteLog "${FUNCNAME[0]}: Can not create BAK file [${FILEBACKUP}] by ONETIME" "WARN" ""
					fi
				fi
				;;
			*             ) 
				if [ -f "${FILEBACKUPDEFAULT}" ]
				then
					WriteLog "${FUNCNAME[0]}: BAK file [${FILEBACKUPDEFAULT}] already exit." "WARN" ""	
				else
					#RemoveFile $FILEBACKUP
					cp $FILE $FILEBACKUPDEFAULT
					#echo "[${FILEBACKUPDEFAULT}]"
					if [ -f "${FILEBACKUPDEFAULT}" ]
					then
						WriteLog "${FUNCNAME[0]}: Created BAK file [${FILEBACKUPDEFAULT}] by DEFAULT" "DUMP" ""	
					else
						WriteLog "${FUNCNAME[0]}: Can not create BAK file [${FILEBACKUPDEFAULT}] by DEFAULT" "WARN" ""
					fi
				fi
				;;
		esac
	else 
		WriteLog "${FUNCNAME[0]}: Original file for backup [${FILE}] does not exist" "WARN" ""
	fi
}

function crontab_job_add               # Add job to crontab (add line to crontab file)
{
	local USERNAME="${1}"
	local STARTTIME="${2}"
	local RUNSCRIPT="${3}"

	local CrontabTemp="$(mktemp)"
	
	#echo "=========== INC VAL =============="
	#echo "USER      : ${USERNAME}"
	#echo "StartTime : ${STARTTIME}"
	#echo "RUNSCRIPT : ${RUNSCRIPT}"
	#echo "=========== INC VAL END =========="
	

        if [ "${STARTTIME}" == "" ] || [ "${RUNSCRIPT}" == "" ]
        then
                WriteLog  "${FUNCNAME[0]}: StartTime [${STARTTIME}] and/or RUNSCRIPT [${RUNSCRIPT}] must be specified" "ERROR" ""
                exit 1
        fi
	
	if [ "${USERNAME}" == "" ]
	then
		local USERNAME="${USER}"
	fi

	WriteLog "Try co create crontab job at [${STARTTIME}] run [${RUNSCRIPT}] for user [${USERNAME}]" "TRY" ""

	
	local CurrentCronJobs="$(crontab -u $USERNAME -l)"
	
	if [ ! "$(crontab -u $USERNAME -l)" ]  # [ "${CurrentCronJobs}" == "no crontab for ${USERNAME}" ]
	then
		WriteLog "${FUNCNAME[0]}: No current Crontab jobs are exist for user [${USERNAME}]" "DUMP" ""
	else
		WriteLog "${FUNCNAME[0]}: Exist Crontab jobs for user [${USERNAME}]" "DUMP" ""
		# export current jobs list
		crontab -u $USERNAME -l >> ${CrontabTemp}
	fi

	#Escape slashes in MASK
	# by several lines and by oneline
	### example: first=${first//Suzy/$second} # replace all Suzy in var $first to $second
	#local replstr="\\/"
	#local EscapedMASK="${RUNSCRIPT//\//$replstr}"
	#AddLineToFile ${CrontabTemp} "${EscapedMASK}$" "${STARTTIME} ${RUNSCRIPT}"
	AddLineToFile ${CrontabTemp} "${RUNSCRIPT//\//\\/}$" "${STARTTIME} ${RUNSCRIPT}" # same in one line. but very hard to undestand
	

	# import New Job List to crontab
	local res=$(cat ${CrontabTemp} | crontab -u $USERNAME -)
	WriteLog "Import crontab jobs result: ${res}" "DUMP" ""
	
	RemoveFile ${CrontabTemp} 
	
	WriteLog "Crontab jobs for user [${USERNAME}] listing" "INFO" ""	
	local res=$(crontab -u "${USERNAME}" -l)
	WriteLog "${res}" "INFO" ""
}

function hostname_change               # TODO Change hostname (several ways)
{
	#echo "${1,,}"	
	local NewHostName="${1}"
	#ocal NewHostName="${NewHostName,,}"

	local DEBUG=0
	if [ ${DEBUG} -eq 1 ] 	
	then	
		echo "=========== INC VAL =============="
		echo "NewHostName  : ${NewHostName}"
		echo "=========== INC VAL END =========="
	fi

        if [ "${NewHostName}" == "" ]
        then
                WriteLog  "${FUNCNAME[0]}: NewHostName [${NewHostName}] must be specified" "ERROR" ""
                exit 1
        fi
	
	local CurrentHostName=$(hostname)
	if [ "${CurrentHostName}" == "${NewHostName}" ]
	then
		WriteLog "${FUNCNAME[0]}: Hostname is already correct [${CurrentHostName}]" "DUMP" ""
	else
		WriteLog "${FUNCNAME[0]}: Try to set new hostname [${NewHostName}]" "DUMP" ""
		hostnamectl set-hostname "${NewHostName}"

		local CurrentHostName=$(hostname)
		if [ "${CurrentHostName}" == "${NewHostName}" ]
        	then
			WriteLog "${FUNCNAME[0]}: Set new Hostname [${NewHostName}] (old name is [${CurrentHostName}]" "MESS" ""
		else
			WriteLog "${FUNCNAME[0]}: Can not set new Hostname [${NewHostName}] (current name is [${CurrentHostName}]" "ERROR" ""
		fi
	fi
}
#xHostName="$(hostname)" #ST-Build2-Unix
#hostname_change "TestHostName"
#hostname_change "${xHostName}" 
#hostname_change "${xHostName}" 


function xService                      # [ Start | Stop | Restart | Status ] Service if it Exist TODO Status and correctly check
{
	# - Start Service
	# - Stop Service
	# - Get status
	# - restart service

        local ServiceName="${1}"
	local Operation="${2,,}" # Start | Stop | Restart | Status
	local checkWay="${3}"	# if this file are exit - service exist
	local xRelease=${Release:-1}

        local DEBUG=0
        if [ ${DEBUG} -eq 1 ]
        then
                echo "=========== INC VAL =============="
                echo "ServiceName    : ${ServiceName}"
                echo "Operation      : ${Operation}"
                echo "Release        : ${Release}"
                echo "xRelease       : ${xRelease}"
		echo "=========== INC VAL END =========="
        fi

        if [ "${ServiceName}" == "" ] || [ "${checkWay}" == "" ] || [ "${Operation}" == "" ]
        then
                WriteLog  "${FUNCNAME[0]}: ServiceName [${ServiceName}], Operation [${Operation}] and checkWay [$checkWay] must be specified" "ERROR" ""
                exit 1
        fi	

	if [ ${Operation} == "start" ]
	then
		# TODO write correct service check func 
		if [ -f "${checkWay}" ] # "/etc/init.d/shturman" ]
		then
			#echo "-- Service Shturman are exist. Try to start it"
		        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] are exist. Try to start it" "TRY" ""
		        if [ $Release -eq 1 ]
		        then
				service ${ServiceName} start
			else
	                	#echo -en "-- ${YELLOW}[ LOCAL TEST MODE ] Skip start shturman service ${NC}\n"
				WriteLog "${FUNCNAME[0]}: Skip start service [${ServiceName}]" "TEST" ""

        		fi
		else
		        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] does not exist." "ERROR" ""
		        exit 1
		fi
	fi

	if [ ${Operation} == "stop" ]
        then
                # TODO write correct service check func
                if [ -f "${checkWay}"  ] # "/etc/init.d/shturman" ]
                then
                        #echo "-- Service Shturman are exist. Try to start it"
                        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] are exist. Try to stop it" "TRY" ""
                        if [ $Release -eq 1 ]
                        then
                                service ${ServiceName} stop
                        else
                                #echo -en "-- ${YELLOW}[ LOCAL TEST MODE ] Skip start shturman service ${NC}\n"
                                WriteLog "${FUNCNAME[0]}: Skip stop service [${ServiceName}]" "TEST" ""

                        fi
                else
                        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] does not exist. Stop operation was skipped" "WARN" ""
                        #exit 1
                fi
        fi
	
	# Disable and enable services if it exist
	if [ ${Operation} == "disable" ]
        then
                # TODO write correct service check func
                if [ -f "${checkWay}"  ] # "/etc/init.d/shturman" ]
                then
                        #echo "-- Service Shturman are exist. Try to start it"
                        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] are exist. Try to disable it" "TRY" ""
                        if [ $Release == 1 ]
                        then
				systemctl disable ${ServiceName}
                                #service ${ServiceName} stop
                        else
                                #echo -en "-- ${YELLOW}[ LOCAL TEST MODE ] Skip start shturman service ${NC}\n"
                                WriteLog "${FUNCNAME[0]}: Skip disable service [${ServiceName}]" "TEST" ""

                        fi
                else
                        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] does not exist. Disable operation was skipped" "WARN" ""
                        #exit 1
                fi
        fi

	if [ ${Operation} == "enable" ]
        then
                # TODO write correct service check func
                if [ -f "${checkWay}"  ] # "/etc/init.d/shturman" ]
                then
                        #echo "-- Service Shturman are exist. Try to start it"
                        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] are exist. Try to enable it" "TRY" ""
                        if [ $Release == 1 ]
                        then
				systemctl enable ${ServiceName}
                                #service ${ServiceName} stop
                        else
                                #echo -en "-- ${YELLOW}[ LOCAL TEST MODE ] Skip start shturman service ${NC}\n"
                                WriteLog "${FUNCNAME[0]}: Skip enable service [${ServiceName}]" "TEST" ""

                        fi
                else
                        WriteLog "${FUNCNAME[0]}: Service [${ServiceName}] does not exist. Enable operation was skipped" "WARN" ""
                        #exit 1
                fi
        fi


	if [ ${Operation} == "status" ]
        then
                service ${ServiceName} status
        fi
	
	if [ ${Operation} == "restart" ]
        then
		xService ${ServiceName} "stop"
		xService ${ServiceName} "start"
        fi
}
#xService "shturman" "start" "/etc/init.d/shturman" 1
#xService "shturman" "stop" "/etc/init.d/shturman" 1
#xService "shturman" "disable" "/etc/init.d/shturman" 1
#xService "shturman" "enable" "/etc/init.d/shturman" 1

function KillProcess
{
	local processMask=${1:-}

	if [ "${processMask}" == "" ]
	then
		WriteLog "${FUNCNAME[0]}: Try to kill process by name: [${processMask}]" "DUMP" ""
	fi

	local procId=$(ps -augxw | grep "${processMask}" | grep -v "grep" | awk '{print $2}')

	echo "$procId"
}
#DEBUG=$TRUE
#KillProcess "bin/ShturmanCore"
#KillProcess "bash"


function countUniqueRowsInFile
{
	DEBUG=1
 
	local fileMask=${1:-}	# Processing file "$(ls $fileMask)"
	local fileOut=${2:-}	# write to file (FULLPATH), if empty - write to scriptfolder (file-line-count_$(date +"%y.%m.%d").log")
	local mask=${3:-}	# include Mask (grep -E "")
	local exclude=${4:-}	# exclude Mask (grep -v -E "")
	local append=${5:0}	# 1 - append to exist file = ">>";     0 - write new = ">"

	if [ "$fileOut" == "" ]
	then
		fileOut="`dirname $0`/file-line-count_$(date +"%y.%m.%d").log"
	fi

	local fileName="$(ls $fileMask)"

	if [ -f "$fileName" ]
	then
		WriteLog "${FUNCNAME[0]}: Get stat from file [$fileMask], to file [$fileOut]" "INFO"
		#local fileName="$(ls $fileMask)"
		WriteLog "${FUNCNAME[0]}: by Mask: [$mask], Exclude: [$exclude]" "INFO"

		if [ "$mask" != "" ] && [ "$exclude" != "" ]
		then
			# Mask and Exclude
			if [ $append -eq 1 ]
			then
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "$exclude" | grep -E "$mask" | sort | uniq -c >> $fileOut 
			else
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "$exclude" | grep -E "$mask" | sort | uniq -c > $fileOut
			fi
			#echo "cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E \"$exclude\" | grep -E \"$mask\" | sort | uniq -c >> $fileOut"
		elif [ "$mask" != "" ] && [ "$exclude" == "" ]
		then
			# Mask only
			WriteLog "${FUNCNAME[0]}: by Mask: [$mask] only" "DUMP"
			if [ $append -eq 1 ]
                        then
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -E "$mask" | sort | uniq -c >> $fileOut
			else
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -E "$mask" | sort | uniq -c > $fileOut
			fi
		elif [ "$mask" == "" ] && [ "$exclude" != "" ]
		then 
			# Exclude only
			if [ $append -eq 1 ]
                        then
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "$exclude" | sort | uniq -c >> $fileOut
			else
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| grep -v -E "$exclude" | sort | uniq -c > $fileOut
			fi
		else
			# NO. Full file process
			if [ $append -eq 1 ]
                        then
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| sort | uniq -c >> $fileOut
			else
				cat ${fileName} | sed -E 's/^\[[0-9:.]{12}\] //g'| sort | uniq -c > $fileOut
			fi
		fi

	else
		WriteLog "${FUNCNAME[0]}: File [$fileMask] does not exist" "WARN"
	fi
	
	# Move *.zip (yerterday and early created) to upload directory
	#mv $(ls /opt/shturman/bin/Log/LogErrorsCount*.zip) /opt/shturman/upload/
}


#countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanCore-$(date +"%y.%m.%d").log" "/opt/shturman/bin/Log/LogErrorsCount_$(date +"%y.%m.%d").log" "ERR|WRN" "пакет|Получен" "1"
#countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanCore-$(date +"%y.%m.%d").log" "/opt/shturman/bin/Log/test_todel.log" "ERR|WRN" "пакет|Получен|Отправка|Посылка" "1"
#countUniqueRowsInFile "/opt/shturman/bin/Log/ShturmanCore-$(date +"%y.%m.%d").log"
#countUniqueRowsInFile "" "" "WRN:|ERR:" ""


function installPacket 		# Install any debian packet if it does not exist
{
        local rPacket="${1}"     	# Packet name like in "apt-get install perl"
        local searchString="${2}"	# Packet name as return by "dpkg-query --list"

        if [ "${rPacket}" == "" ] || [ "${searchString}" == "" ]
        then
                WriteLog "rPacket [${rPacket}] and searchString [${searchString}] must be specified. Aborted."  "ERROR" ""

        else
                #PackageExist="$(dpkg-query --list | grep 'cifs')"

                #if [ "$(dpkg-query --list | grep '${searchString}'" == "" ]
                if [ "$(dpkg-query --list | grep \"${searchString}\")" == "" ]
                #if [ "$PackageExist" == "" ]
                then
                        WriteLog "Try to install ${rPacket} utils" "TRY" ""
                        WriteLog "$(apt-get -y install ${rPacket})" "INFO" ""
                fi
        fi
}


function set_hostname          # Rename PC    ex:  set_hostname "NewHostName" "[Reboot|Reload]"
{
        local nHostname="${1}"              # New HostName
        local actionRequired="${2:-}"       # reboot after change name (any symbol)
	actionRequired=${actionRequired^^}  # Tu opper case

        local DEBUG=0
        if [ ${DEBUG} -eq 1 ]
        then
                echo "=========== INC VAL =============="
                echo "nHostname      : ${nHostname}"
                echo "actionRequired : ${actionRequired}"
		echo "=========== INC VAL END =========="
        fi
	
	echo "$nHostname" > /etc/hostname 
	AddLineToFile "/etc/hosts"  "127.0.0.1" "127.0.0.1       ${nHostname}"	
	AddLineToFile "/etc/hosts"  "^::1" "::1             ${nHostname} ip6-localhost ip6-loopback"	

}
#set_hostname "ST-Build2-Unix" 
#set_hostname "ST-Build2-Unix"

#ENDCOMMONFUNCTIONS#
 
