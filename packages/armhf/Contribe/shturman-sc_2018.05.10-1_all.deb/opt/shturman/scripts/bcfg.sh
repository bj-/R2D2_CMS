#!/bin/bash


DEBUG=0; # Debug mode (for this script).

StartFromFolder="`pwd`"

# Script file name and path
ScriptFullPath=`realpath -s $0` # Script full path. ex: [/home/user/PackageBuilder/CreatePacket.sh]
ScriptName="`basename $0`"      # only script file name. ex: [CreatePacket.sh]
ScriptDirPath=`dirname ${ScriptFullPath}`       # only script home directory. ex: [/home/user/PackageBuilder] wo / at end

# === Includes ===
source "${ScriptDirPath}/functions.sh"
source "${ScriptDirPath}/functions-shturman.sh"
echo "source \"${ScriptDirPath}/functions-shturman.sh\""

# run as root
isAdm

Release=1 
if [ -f "/etc/ShturmanDemoInstall.txt" ]
then
        Release=0
fi


echo " "
echo " "
echo "========================================================"
echo "          Shturman Configuration script                 "
echo "========================================================"
echo " "
echo "  Usage:"
echo "      [Enter]  - type default value"
echo "      [Ctrl-C] - Exit"
echo " "
# Show curent configuration
WriteLog "===  Current Configuration ===" "INFO" ""
BlockConfigurationReport


echo " "
echo " "
echo "Please specify block parameters, or press ENTER for default values, or Ctrl-C to Exit" "INFO" ""

#WriteLog "Enter full Block Serail No (like to [STB08626] or [STB10252] or [STB], Default:[STB0001]" "INFO" ""
read -ep "$(echo -en ${PURPLE}Block Serail No${NC}) (like to [$(echo -en ${WHITE}STB08626${NC})], Default:[$(echo -en ${WHITE}STB0001]${NC})): " BlockSerialNo

#WriteLog "Enter Block Orientation : [1] - cable from down side; [2] cable from upper side, Default=1" "INFO" ""
read -ep "$(echo -en ${PURPLE}BOVI Orientation${NC}) ([$(echo -en ${WHITE}1${NC})] - cable from $(echo -en ${WHITE}down${NC}) side; [$(echo -en ${WHITE}2${NC})] cable from $(echo -en ${WHITE}upper${NC}) side, Default=$(echo -en ${WHITE}1${NC})): " BOVIOrientation


#WriteLog "Enter Server Address and port: Default:[192.168.51.88:45796]" "INFO" ""
#read -p "ServerAddress: " ServerAddress

if [ "${BlockSerialNo}" == "" ]
then
	BlockSerialNo="STB0001"
fi

if [ "${BOVIOrientation}" == "" ]
then
	BOVIOrientation="1"
fi


#echo "BlockSerialNo [${BlockSerialNo}]"
#echo "BOVI Orientation   [${BOVIOrientation}]"
#echo "ServerAddress  [${ServerAddress}]"

# Stop Service
xService "servicestracking" "stop" "/lib/systemd/system/servicestracking.service" $Release
xService "shturman" "stop" "/etc/init.d/shturman" $Release
#xService "shturmnan" "stop"

# Deploy new cfg

if [ "${BOVIOrientation}" == "1" ]
then 
	BOVIOrientation="true"
else
	BOVIOrientation="false"
fi

ini_change_parameter "/opt/shturman/bin/Shturman.ini" "Hub" "BlockSerialNo=" "${BlockSerialNo}"
ini_change_parameter "/opt/shturman/bin/Shturman.ini" "EInk" "Orientation=" "${BOVIOrientation}"


# Start Shturman Service
#xService "shturmnan" "start"
xService "shturman" "start" "/etc/init.d/shturman" $Release
xService "servicestracking" "start" "/lib/systemd/system/servicestracking.service" $Release

# Report Config

WriteLog "===  Deployed Configuration ===" "INFO" ""
BlockConfigurationReport

exit 0
