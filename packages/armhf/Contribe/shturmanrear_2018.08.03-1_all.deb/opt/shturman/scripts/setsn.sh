#!/bin/bash

DEBUG=0;

# Script file name
ScriptName="`basename $0`"
# Script called from folder
StartFromFolder="`pwd`"
# Script Execution directory
ScriptRealPathwoSLinks=`realpath -s $0`
ScriptRealDir=`dirname ${ScriptRealPathwoSLinks}`
ScriptDir="${ScriptRealDir}"

source "${ScriptDir}/functions.sh"

DEBUG=0;

NewBlockSerialName="${1^^}"
NewBlockSerialName="$(echo "${NewBlockSerialName}" | xargs)"

if [ ${DEBUG} -eq 1 ]
then
        echo "================================ echo variables BEGIN ====================================="
        echo "ScriptName: ${ScriptName}"
        echo "ScriptDir:  ${ScriptDir}"
        echo "StartFromFolder: ${StartFromFolder}"
        echo "ScriptRealPath: ${ScriptRealPath}"
        echo "ScriptRealPathwoSLinks: ${ScriptRealPathwoSLinks}"
        echo "ScriptRealDir: ${ScriptRealDir}"
        echo "================================  echo variables END  ====================================="
        #exit 0
else
	DEBUG=0;
fi

isAdm # Check Root rights

if [ "${1,,}" == "--help" ]
then
        echo "
 =====
 Using
 =====

      setsn.sh [NewBlockSerialName] 

         [[NewBlockSerialName] - full name. Like to STB08692 or STB10252

      Example:
	/opt/packet/setsn.sh STB10505
"
        exit 0
fi



Release=1

if [ -f "/etc/ShturmanDemoInstall.txt" ]
then
        Release=0
        #echo -en "-- ${YELLOW}=== === === === === === === === === === === === === === === === === === === === ==${NC}\n"
        #echo -en "-- ${YELLOW}[ INFO  ] This script run in LOCAL TEST MODE (w/o start and stop Shturman service)${NC}\n"
        #echo -en "-- ${YELLOW}=== === === === === === === === === === === === === === === === === === === === ==${NC}\n"
fi


#echo "[${NewBlockSerialName}]"


#exit 0

if [ "${NewBlockSerialName}" == "" ]
then
	WriteLog "New BlockSerialNo [${NewBlockSerialName}] must be specified" "ERROR" ""
	exit 1
fi

if [ -f "/etc/init.d/shturman" ]
then
        #echo "-- Service Shturman are exist. Try to stop it"
        WriteLog "Service Shturman are exist. Try to stop it" "TRY" ""
        if [ $Release == 1 ]
        then
                service shturman stop
        else
                #echo -en "-- ${YELLOW} [ LOCAL TEST MODE ] skip stop service ${NC}\n"
                WriteLog "Skip stop service" "TEST" ""
        fi
fi

sed -i "s/^BlockSerialNo=.*/BlockSerialNo=${NewBlockSerialName}/" /opt/shturman/bin/Shturman.ini

# Start Shturman Service
if [ -f "/etc/init.d/shturman" ]
then
        #echo "-- Service Shturman are exist. Try to start it"
        WriteLog "Service Shturman are exist. Try to start it" "TRY" ""
        if [ $Release == 1 ]
        then
                service shturman start
        else
                #echo -en "-- ${YELLOW}[ LOCAL TEST MODE ] Skip start shturman service ${NC}\n"
                WriteLog "Skip start shturman service" "TEST" ""

        fi
else
        WriteLog "Service Shturman does not exist." "ERROR" ""
        exit 1
fi

# PCConfigurationReport

WriteLog "Configuration Report" "INFO" ""
WriteLog "Hostname:          [${PURPLE}$(hostname)${NC}]" "INFO" ""
WriteLog "BlockSerialNo:     [${PURPLE}$(sudo cat /opt/shturman/bin/Shturman.ini | grep "^BlockSerialNo=" )${NC}]" "INFO" ""
WriteLog "Block Orientation: [${PURPLE}$(sudo cat /opt/shturman/bin/Shturman.ini | grep "^Orientation")${NC}] (true = cable from BOTTOM side / false = cable from UP side) " "INFO" ""
WriteLog "Packets installed: [${PURPLE}$(dpkg-query --list | grep "turman" )${NC}]" "INFO" ""
WriteLog "Packet Version:    [${PURPLE}--${NC}]" "INFO" ""
WriteLog "Metro IP Address   [${PURPLE}--${NC}]" "INFO" ""
WriteLog "WiFi IP Address    [${PURPLE}--${NC}]" "INFO" ""

exit 0
